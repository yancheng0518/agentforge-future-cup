import { useCallback, useEffect, useRef, useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import { api, post } from './api'
import type { Event, Health, ProjectFile, Run, Step, TaskDefinition } from './types'
import { Management } from './Management'
import { buildRequirement, getRunSummary, getTestEvidence, resolveIntent, runTitle, runUserMessage } from './conversation'

type View = 'tasks' | 'agents' | 'knowledge'
type Panel = 'changes' | 'validation' | 'activity' | 'project' | null
const stateNames: Record<string, string> = { queued: '等待开始', running: '进行中', succeeded: '已完成', failed: '执行失败', blocked: '执行受阻', needs_human: '需要处理', pending: '待执行', skipped: '已跳过' }
const eventNames: Record<string, string> = { schedule: '分工', tool: '工具', agent: 'Agent 输出', validation: '验证', feedback: '修正反馈', status: '状态', error: '错误', snapshot: '快照' }
const examples = [
  { icon: 'check', text: '给待办加上完成状态和筛选', id: 'completion' },
  { icon: 'edit', text: '支持重命名、删除和批量完成', id: 'bulk_edit' },
  { icon: 'sort', text: '按优先级排序，支持分页查询', id: 'priority_query' },
  { icon: 'file', text: '用 JSON 导入、导出并合并待办', id: 'json_merge' },
]
const object = (value: unknown): Record<string, unknown> => value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {}
const printable = (value: unknown) => typeof value === 'string' ? value : JSON.stringify(value, null, 2)
const timestamp = (value?: string) => value ? new Intl.DateTimeFormat('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value)) : ''
const selectedFromLocation = () => new URLSearchParams(window.location.hash.slice(1)).get('task')

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    forge: <path d="M4 7h16l-3 4H7zM9 11v5l-3 4h12l-3-4v-5M9 3h6" />,
    plus: <path d="M12 5v14M5 12h14" />, send: <path d="M12 20V4m-6 6 6-6 6 6" />,
    check: <path d="m5 12 4 4L19 6" />, close: <path d="m6 6 12 12M6 18 18 6" />,
    search: <><circle cx="10" cy="10" r="6" /><path d="m15 15 6 6" /></>,
    settings: <><path d="M4 7h16M4 17h16" /><circle cx="9" cy="7" r="3" /><circle cx="16" cy="17" r="3" /></>,
    folder: <path d="M3 6h7l2 3h9v11H3V6Z" />,
    book: <path d="M3 4h7l2 2 2-2h7v16h-7l-2 1-2-1H3V4Zm9 2v15" />,
    agents: <><circle cx="9" cy="8" r="3" /><path d="M3 21v-3a6 6 0 0 1 12 0v3m2-16a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 5" /></>,
    panel: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M9 4v16" /></>,
    chevron: <path d="m9 5 7 7-7 7" />, code: <path d="m8 6-6 6 6 6m8-12 6 6-6 6m-3-14-2 16" />,
    file: <path d="M5 3h9l5 5v13H5V3Zm9 0v6h5M8 13h8M8 17h5" />,
    edit: <path d="m15 4 5 5M4 20l5-1L21 7l-5-5L4 14v6Z" />,
    sort: <path d="M8 4v16m-4-4 4 4 4-4M15 5h6m-6 6h4m-4 6h2" />,
    refresh: <path d="M20 8a8 8 0 1 0 0 8m0-13v5h-5" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    download: <path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5" />,
    alert: <><circle cx="12" cy="12" r="9" /><path d="M12 7v6m0 4h.01" /></>,
  }
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] ?? paths.file}</svg>
}
function Code({ value, diff = false }: { value: string; diff?: boolean }) {
  return <div className="code-scroll" tabIndex={0} aria-label={diff ? '代码修改差异' : '项目代码'}><pre>{value.split('\n').map((line, i) => <span key={i} className={`code-line ${diff && line.startsWith('+') ? 'addition' : diff && line.startsWith('-') ? 'deletion' : diff && line.startsWith('@@') ? 'hunk' : ''}`}><span className="line-number" aria-hidden="true">{i + 1}</span><code>{line || ' '}</code></span>)}</pre></div>
}
function EvidenceEvent({ event }: { event: Event }) {
  return <article className={`evidence-event ${event.type}`}><div><span>{eventNames[event.type] ?? event.type}</span><time>{timestamp(event.timestamp)}</time></div><p>{event.message}</p>{event.data != null && <details><summary>输入与输出</summary><pre>{printable(event.data)}</pre></details>}</article>
}
function Review({ step }: { step: Step }) {
  const output = object(step.output)
  return <section className="review-section"><div className="section-line"><h3>{step.label || '代码审查'}</h3><span className={output.passed === true ? 'success-text' : 'muted'}>{output.passed === true ? '通过' : output.passed === false ? '发现问题' : stateNames[step.status] ?? step.status}</span></div><p>{typeof output.summary === 'string' ? output.summary : '尚未获得完整审查结果。'}</p>{Array.isArray(output.issues) && output.issues.length > 0 && <ul>{output.issues.map((issue, index) => <li key={index}>{printable(issue)}</li>)}</ul>}<details><summary>完整审查记录</summary><pre>{printable(step)}</pre></details></section>
}

export default function App() {
  const [view, setView] = useState<View>('tasks')
  const [health, setHealth] = useState<Health | null>(null)
  const [tasks, setTasks] = useState<TaskDefinition[]>([])
  const [runs, setRuns] = useState<Run[]>([])
  const [selectedRun, setSelectedRun] = useState<string | null>(selectedFromLocation)
  const [run, setRun] = useState<Run | null>(null)
  const [draft, setDraft] = useState('')
  const [mode, setMode] = useState<'live' | 'mock'>('live')
  const [taskOverride, setTaskOverride] = useState('')
  const [workflowOverride, setWorkflowOverride] = useState('')
  const [optionsOpen, setOptionsOpen] = useState(false)
  const [panel, setPanel] = useState<Panel>(null)
  const [sourceMode, setSourceMode] = useState(false)
  const [projectFiles, setProjectFiles] = useState<ProjectFile[]>([])
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [pollVersion, setPollVersion] = useState(0)
  const [refreshing, setRefreshing] = useState(false)
  const [search, setSearch] = useState('')
  const [searchOpen, setSearchOpen] = useState(false)
  const [confirmApply, setConfirmApply] = useState(false)
  const [environmentOpen, setEnvironmentOpen] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)
  const [narrow, setNarrow] = useState(() => window.matchMedia('(max-width: 1050px)').matches)
  const [tick, setTick] = useState(Date.now())
  const alive = useRef(false)
  const input = useRef<HTMLTextAreaElement>(null)
  const searchInput = useRef<HTMLInputElement>(null)
  const applyDialog = useRef<HTMLDialogElement>(null)
  const mobileDialog = useRef<HTMLDialogElement>(null)
  const detailPanel = useRef<HTMLElement>(null)
  const submitGuard = useRef(false)
  const selection = useRef(selectedRun)
  const navigationVersion = useRef(0)

  const refresh = useCallback(async () => {
    setRefreshing(true)
    try {
      const [nextHealth, nextTasks, nextRuns] = await Promise.all([api<Health>('/health'), api<TaskDefinition[]>('/tasks'), api<Run[]>('/runs')])
      if (!alive.current) return
      setHealth(nextHealth); setTasks(nextTasks); setRuns(nextRuns); setError('')
    } catch (e) { if (alive.current) { setHealth(null); setError(e instanceof Error ? e.message : String(e)) } }
    finally { if (alive.current) { setLoading(false); setRefreshing(false) } }
  }, [])
  useEffect(() => { alive.current = true; void refresh(); return () => { alive.current = false } }, [refresh])
  useEffect(() => {
    const media = window.matchMedia('(max-width: 1050px)')
    const update = () => setNarrow(media.matches)
    media.addEventListener('change', update)
    return () => media.removeEventListener('change', update)
  }, [])
  const panelOpen = panel !== null
  useEffect(() => {
    if (!panelOpen || !narrow) return
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null
    detailPanel.current?.querySelector<HTMLButtonElement>('button')?.focus()
    return () => { if (previous?.isConnected) previous.focus() }
  }, [panelOpen, narrow])
  useEffect(() => {
    const navigate = () => { const id = selectedFromLocation(); selection.current = id; navigationVersion.current++; setSelectedRun(id); setRun(null); setView('tasks'); setPanel(null) }
    window.addEventListener('hashchange', navigate)
    return () => window.removeEventListener('hashchange', navigate)
  }, [])
  useEffect(() => {
    if (!selectedRun) { setRun(null); return }
    let cancelled = false
    let timer: ReturnType<typeof setTimeout>
    const poll = async () => {
      try {
        const next = await api<Run>(`/runs/${selectedRun}`)
        if (cancelled) return
        setRun(next)
        setRuns(previous => [next, ...previous.filter(item => item.id !== next.id)].sort((a, b) => b.created_at.localeCompare(a.created_at)))
        if (['queued', 'running'].includes(next.status)) timer = setTimeout(poll, 1000)
      } catch (e) { if (!cancelled) { setError(e instanceof Error ? e.message : String(e)); timer = setTimeout(poll, 5000) } }
    }
    setRun(previous => previous?.id === selectedRun ? previous : null)
    void poll()
    return () => { cancelled = true; clearTimeout(timer) }
  }, [selectedRun, pollVersion])
  const running = !!run && ['queued', 'running'].includes(run.status)
  const hasActiveRuns = runs.some(item => ['queued', 'running'].includes(item.status))
  useEffect(() => {
    if (!hasActiveRuns) return
    let cancelled = false
    const timer = setInterval(() => {
      void api<Run[]>('/runs').then(next => { if (!cancelled) setRuns(next) }).catch(() => { /* Detail polling reports connection errors. */ })
    }, 5000)
    return () => { cancelled = true; clearInterval(timer) }
  }, [hasActiveRuns])
  useEffect(() => { if (!running) return; const timer = setInterval(() => setTick(Date.now()), 1000); return () => clearInterval(timer) }, [running])
  useEffect(() => {
    if (confirmApply && !applyDialog.current?.open) applyDialog.current?.showModal()
    if (!confirmApply && applyDialog.current?.open) applyDialog.current.close()
  }, [confirmApply])
  useEffect(() => {
    if (mobileNav && !mobileDialog.current?.open) mobileDialog.current?.showModal()
    if (!mobileNav && mobileDialog.current?.open) mobileDialog.current.close()
  }, [mobileNav])
  useEffect(() => { if (searchOpen) searchInput.current?.focus() }, [searchOpen, mobileNav])
  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault(); setSearchOpen(true); if (window.innerWidth <= 760) setMobileNav(true)
      }
      if (event.key === 'Escape') { setPanel(null); setOptionsOpen(false); setEnvironmentOpen(false) }
    }
    window.addEventListener('keydown', shortcut); return () => window.removeEventListener('keydown', shortcut)
  }, [])

  const intent = resolveIntent(draft)
  const taskId = taskOverride || intent.taskId
  const task = tasks.find(item => item.id === taskId)
  const workflowId = (workflowOverride || intent.workflowId) as 'development' | 'review'
  const activeTaskId = run?.task_id ?? taskId ?? 'completion'
  const activeTask = run?.task ?? tasks.find(item => item.id === activeTaskId)
  const events = run?.events ?? []
  const steps = run?.steps ?? []
  const test = run ? getTestEvidence(run) : null
  const summary = run ? getRunSummary(run) : null
  const userMessage = run ? runUserMessage(run) : ''
  const userPreview = run && userMessage === run.requirement && (userMessage.startsWith('#') || userMessage.length > 180) ? `任务：${runTitle(run)}` : userMessage.length > 500 ? userMessage.slice(0, 500) + '…' : userMessage
  const diffFiles = run?.diff?.files ?? []
  const changedFiles = diffFiles.filter(file => file.before !== file.after)
  const canApply = run?.status === 'succeeded' && test?.status === 'passed' && run.workflow_id === 'development' && !run.applied && activeTaskId === 'completion' && changedFiles.length > 0
  const plan = object(steps.find(step => step.id === 'plan' && step.status === 'succeeded')?.output)
  const currentSteps = steps.filter(step => ['queued', 'running'].includes(step.status))
  const reviews = steps.filter(step => (step.id.endsWith('/review') || step.id.endsWith('/inspect') || ['review', 'inspect'].includes(step.id)) && (step.attempt ?? 0) === (run?.attempt ?? 0))
  const activity = events.filter(event => ['agent', 'feedback', 'error'].includes(event.type))
  const recent = runs.filter(item => `${runTitle(item)} ${item.requirement}`.toLowerCase().includes(search.toLowerCase()))
  const liveReady = !!health?.model.configured
  const canSubmit = !!draft.trim() && !!task && !!health && !busy && (mode === 'live' ? liveReady : task.id === 'completion') && !!health.sandbox.available
  const endedAt = events.filter(event => event.type === 'status' || event.type === 'error').at(-1)?.timestamp
  const elapsed = run ? Math.max(0, Math.round(((running ? tick : new Date(endedAt ?? run.updated_at ?? run.created_at).getTime()) - new Date(run.created_at).getTime()) / 1000)) : 0
  useEffect(() => {
    if (panel !== 'project' || run || selectedRun) return
    let cancelled = false; setProjectFiles([])
    void api<{ files: ProjectFile[] }>(`/project?task_id=${encodeURIComponent(taskId ?? 'completion')}`)
      .then(result => { if (!cancelled) setProjectFiles(result.files) })
      .catch(e => { if (!cancelled) setError(e instanceof Error ? e.message : String(e)) })
    return () => { cancelled = true }
  }, [panel, taskId, run, selectedRun])

  function selectRun(id: string | null) {
    selection.current = id; navigationVersion.current++
    setSelectedRun(id); setRun(previous => previous?.id === id ? previous : null); setView('tasks')
    setError(''); setNotice(''); setPanel(null); setMobileNav(false); setConfirmApply(false)
    window.history.replaceState(null, '', id ? `#task=${encodeURIComponent(id)}` : window.location.pathname)
  }
  function newTask() { selectRun(null); requestAnimationFrame(() => input.current?.focus()) }
  function useExample(example: typeof examples[number]) { setDraft(example.text); setTaskOverride(example.id); setWorkflowOverride(''); input.current?.focus() }
  async function startRun(event: FormEvent) {
    event.preventDefault()
    if (!canSubmit || !task || submitGuard.current) return
    const origin = navigationVersion.current
    const submittedDraft = draft
    submitGuard.current = true; setBusy(true); setError(''); setNotice('')
    try {
      const next = await post<Run>('/runs', { requirement: buildRequirement(draft.trim(), task), task_id: task.id, workflow_id: workflowId, mode })
      if (!alive.current) return
      setRuns(previous => [next, ...previous.filter(item => item.id !== next.id)])
      if (navigationVersion.current === origin) { selectRun(next.id); setRun(next); setDraft(current => current === submittedDraft ? '' : current); setTaskOverride(''); setWorkflowOverride(''); setOptionsOpen(false) }
    } catch (e) { if (alive.current && navigationVersion.current === origin) setError(e instanceof Error ? e.message : String(e)) }
    finally { submitGuard.current = false; if (alive.current) setBusy(false) }
  }
  async function resumeRun() {
    if (!run || busy) return
    const id = run.id
    setBusy(true); setError('')
    try {
      await post(`/runs/${id}/resume`)
      if (!alive.current) return
      if (selection.current === id) { setNotice('恢复请求已提交，正在读取最新执行状态。'); setPollVersion(value => value + 1) }
    } catch (e) { if (alive.current && selection.current === id) setError(e instanceof Error ? e.message : String(e)) }
    finally { if (alive.current) setBusy(false) }
  }
  async function applyRun() {
    if (!run || !canApply || busy) return
    const id = run.id
    setBusy(true); setError('')
    try {
      await post(`/runs/${id}/apply`, { confirmed: true })
      if (!alive.current) return
      setConfirmApply(false)
      if (selection.current === id) { setNotice('修改已应用到待办示例项目。'); setPollVersion(value => value + 1) }
      void refresh()
    }
    catch (e) { if (alive.current && selection.current === id) setError(e instanceof Error ? e.message : String(e)) } finally { if (alive.current) setBusy(false) }
  }
  function exportCandidate() {
    if (!run) return
    for (const file of changedFiles) {
      const url = URL.createObjectURL(new Blob([file.after], { type: 'text/x-python;charset=utf-8' }))
      const link = document.createElement('a'); link.href = url; link.download = `${activeTaskId}-${run.id.slice(0, 8)}-${file.path}`; link.click()
      setTimeout(() => URL.revokeObjectURL(url), 1000)
    }
  }
  function navigate(next: View) { navigationVersion.current++; setView(next); setPanel(null); setMobileNav(false); setError(''); setNotice('') }

  const navigation = <>
    <div className="sidebar-brand"><Icon name="forge" size={23} /><span>AgentForge</span><button className="icon-button mobile-only" aria-label="关闭导航" onClick={() => setMobileNav(false)}><Icon name="close" /></button></div>
    <button className="new-task" onClick={newTask}><Icon name="plus" /><span>新任务</span></button>
    <button className="nav-row" onClick={() => setSearchOpen(value => !value)} aria-expanded={searchOpen}><Icon name="search" /><span>搜索任务</span><kbd>Ctrl K</kbd></button>
    {searchOpen && <input ref={searchInput} className="history-search" aria-label="搜索历史任务" placeholder="搜索需求或任务名称" value={search} onChange={event => setSearch(event.target.value)} />}
    <div className="history-label">任务记录 <span>{runs.length}</span></div>
    <nav className="task-history" aria-label="任务记录">{loading ? <div className="skeleton" aria-label="正在读取历史任务"><i /><i /><i /></div> : recent.length ? recent.map(item => <button key={item.id} className={`history-item ${view === 'tasks' && selectedRun === item.id ? 'selected' : ''}`} aria-current={view === 'tasks' && selectedRun === item.id ? 'page' : undefined} onClick={() => selectRun(item.id)} title={runTitle(item)}><span className={`task-dot ${item.status}`} /><span className="history-copy"><span>{runTitle(item)}</span><small>{item.mode === 'mock' ? '模拟 · ' : ''}{stateNames[item.status] ?? item.status} · {timestamp(item.created_at)}</small></span></button>) : <p className="sidebar-empty">{search ? '没有找到匹配的任务。' : '你的任务会保存在这里。'}</p>}</nav>
    <div className="sidebar-bottom"><button className={`nav-row ${view === 'agents' ? 'selected' : ''}`} onClick={() => navigate('agents')}><Icon name="agents" /><span>Agent 设置</span></button><button className={`nav-row ${view === 'knowledge' ? 'selected' : ''}`} onClick={() => navigate('knowledge')}><Icon name="book" /><span>知识资料</span></button><div className="workspace-identity"><span className="workspace-avatar">AF</span><div>本地工作区<small>待办示例项目</small></div><span className={`connection-dot ${health ? 'connected' : ''}`} title={health ? '本地服务已连接' : '尚未连接后端'} /></div></div>
  </>

  return <div className={`app-shell ${panel ? 'with-panel' : ''}`}>
    <aside className="sidebar desktop-sidebar">{navigation}</aside>
    <dialog aria-label="任务导航" className="mobile-navigation" ref={mobileDialog} onCancel={() => setMobileNav(false)} onClose={() => setMobileNav(false)}>{mobileNav && navigation}</dialog>
    <div className="main-shell">
      <header className="workspace-header"><div className="header-leading"><button className="icon-button mobile-only" aria-label="打开任务导航" onClick={() => setMobileNav(true)}><Icon name="panel" /></button><button className="project-label" onClick={() => setPanel(panel === 'project' ? null : 'project')}><Icon name="folder" size={17} /><span>待办示例</span><Icon name="chevron" size={12} /></button><span className="header-divider">/</span><span className="header-title">{view === 'agents' ? 'Agent 设置' : view === 'knowledge' ? '知识资料' : run ? runTitle(run) : selectedRun ? '读取任务…' : '新任务'}</span></div><button className={`environment-button ${!health?.sandbox.available ? 'warning-text' : ''}`} onClick={() => setEnvironmentOpen(value => !value)} aria-expanded={environmentOpen}><span className={`connection-dot ${health?.sandbox.available ? 'connected' : ''}`} /><span>{loading ? '连接中' : !health ? '未连接' : health.sandbox.available ? '环境就绪' : '需要启动隔离环境'}</span><Icon name="settings" size={15} /></button></header>
      {environmentOpen && <section className="environment-details" aria-label="运行环境"><div><strong>运行环境</strong><button className="text-button" disabled={refreshing} onClick={() => void refresh()}><Icon name="refresh" size={14} />{refreshing ? '检查中…' : '重新检查'}</button></div><p>{health ? '后端已连接' : '后端未连接'} · {health?.sandbox.available ? 'Docker 隔离环境可用' : health?.sandbox.reason ?? '请启动项目的前后端服务。'}</p><p>{liveReady ? `默认模型：${health?.model.model}。${health?.model.verified ? '当前服务已验证模型调用。' : '已读取本地配置；实际可用性以本次调用结果为准。'}` : '真实模型尚未配置；可在本地 .env 中配置，或选择模拟演示。'}</p></section>}
      {error && <div className="message error-message" role="alert"><Icon name="alert" /><span>{error}</span><button className="text-button" onClick={() => { void refresh(); setPollVersion(value => value + 1) }}>重新连接</button><button className="icon-button" aria-label="关闭错误提示" onClick={() => setError('')}><Icon name="close" size={16} /></button></div>}
      {notice && <div className="message notice-message" role="status"><Icon name="check" /><span>{notice}</span><button className="icon-button" aria-label="关闭提示" onClick={() => setNotice('')}><Icon name="close" size={16} /></button></div>}
      <div className="workspace-content">
        <main className={`conversation-main ${!selectedRun && view === 'tasks' ? 'is-new' : ''}`} inert={panelOpen && narrow}>
          {view !== 'tasks' ? <Management view={view} /> : !selectedRun ? <div className="new-conversation">
            <div className="welcome"><div className="welcome-mark"><Icon name="forge" size={32} /></div><h1>想为项目做些什么？</h1><p>描述需求，让 Agent 团队完成开发、测试和审查。</p></div>
            <form className="composer" onSubmit={startRun}>
              <label className="sr-only" htmlFor="task-request">描述你的需求</label><textarea id="task-request" ref={input} value={draft} onChange={event => { setDraft(event.target.value); setTaskOverride('') }} placeholder="例如：给待办加上完成状态，能筛选已完成的任务…" rows={3} maxLength={4000} onKeyDown={event => { if ((event.ctrlKey || event.metaKey) && event.key === 'Enter' && !event.nativeEvent.isComposing) { event.preventDefault(); event.currentTarget.form?.requestSubmit() } }} />
              <div className="composer-toolbar"><div className="composer-context"><span><Icon name="folder" size={14} />待办示例</span><button type="button" className={`mode-control ${mode === 'mock' ? 'warning-text' : ''}`} onClick={() => setOptionsOpen(value => !value)} aria-expanded={optionsOpen}><span className={`mode-dot ${mode}`} />{mode === 'live' ? '真实模型' : '模拟演示'}<Icon name="settings" size={13} /></button></div><button className="send-button" type="submit" disabled={!canSubmit} aria-label={busy ? '正在提交任务' : '开始任务'} title="开始任务 · Ctrl+Enter"><Icon name="send" size={19} /><span>{busy ? '提交中' : '开始任务'}</span></button></div>
              {optionsOpen && <div className="composer-settings"><label>执行方式<select aria-label="执行方式" value={mode} onChange={event => setMode(event.target.value as 'live' | 'mock')}><option value="live">真实模型 · 使用平台额度</option><option value="mock">模拟演示 · 固定输出</option></select></label><label>任务范围<select aria-label="任务范围" value={taskOverride} onChange={event => setTaskOverride(event.target.value)}><option value="">根据输入匹配</option>{tasks.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>处理方式<select aria-label="处理方式" value={workflowOverride} onChange={event => setWorkflowOverride(event.target.value)}><option value="">根据输入判断</option><option value="development">实现需求</option><option value="review">仅审查代码</option></select></label><p>真实模型会消耗平台额度。模拟演示使用预设输出，仅支持完成状态任务。</p></div>}
            </form>
            <div className="composer-guidance" aria-live="polite">{!health && !loading ? <span className="warning-text">请先连接后端服务。<button className="text-button" onClick={() => void refresh()}>重新连接</button></span> : health && !health.sandbox.available ? <span className="warning-text">隔离环境尚未就绪，准备好后才能执行任务。<button className="text-button" onClick={() => setEnvironmentOpen(true)}>查看原因</button></span> : mode === 'live' && !liveReady && !loading ? <span className="warning-text">请配置真实模型，或在执行设置中选择模拟演示。</span> : mode === 'mock' && task && task.id !== 'completion' ? <span className="warning-text">这项需求需要真实模型。<button className="text-button" onClick={() => setMode('live')}>切换真实模型</button></span> : draft.trim() ? task ? <><span>{workflowId === 'review' ? '将审查' : '将实现'}：{task.name}</span><button className="text-button" onClick={() => setOptionsOpen(value => !value)}>调整范围</button></> : <><span>{intent.reason || '请选择一个当前支持的任务范围。'}</span><button className="text-button" onClick={() => setOptionsOpen(true)}>选择范围</button></> : <span>当前连接待办示例，支持以下四类需求。Ctrl + Enter 发送。</span>}</div>
            {task && draft.trim() && <details className="scope-details"><summary>查看本次验收范围 · {task.expected_tests} 项独立测试</summary><p>按以下固定契约实现并验收；额外要求需要另行验证。</p><pre>{task.requirement}</pre></details>}
            {!draft.trim() && <div className="suggestions" aria-label="试试这些需求">{examples.map(example => <button key={example.id} onClick={() => useExample(example)}><Icon name={example.icon} size={19} /><span>{example.text}</span><Icon name="chevron" size={14} /></button>)}</div>}
            <p className="home-footnote">每次任务先在副本中修改，你检查结果后再决定是否应用。</p>
          </div> : !run ? <div className="thread-skeleton skeleton" aria-label="正在读取任务"><i /><i /><i /><p>正在读取任务记录…</p></div> : <div className="conversation-thread">
            <div className="thread-topline"><span>{timestamp(run.created_at)}</span><span className={`run-mode ${run.mode}`}>{run.mode === 'mock' ? '模拟演示 · 固定输出' : '真实模型'}{run.fault_injection === true ? ' · 预设缺陷' : ''}</span></div>
            <article className="user-message"><span className="sr-only">你的需求</span><p>{userPreview}</p>{userPreview !== userMessage && <details><summary>查看完整需求</summary><pre>{userMessage}</pre></details>}</article>
            <article className="assistant-message"><div className="assistant-heading"><span className="assistant-mark"><Icon name="forge" size={21} /></span><strong>AgentForge</strong><span>{run.mode === 'mock' ? '模拟执行记录' : '协作执行记录'}</span></div>
              <p className="task-understanding">{run.workflow_id === 'review' ? '检查' : '处理'}「{activeTask?.name ?? '待办示例需求'}」，{run.workflow_id === 'review' ? '保留代码并给出审查结论。' : '在独立副本中完成修改并验证。'}</p>
              {run.mode === 'mock' && <p className="mode-explanation">这是模拟演示：预设首轮遗漏与修正输出，模型调用为 0；测试使用实际 Docker 结果。</p>}
              {typeof plan.summary === 'string' && <details className="model-plan"><summary>{run.mode === 'mock' ? '模拟规划结果' : 'Agent 任务计划'}</summary><p>{plan.summary}</p>{Array.isArray(plan.tasks) && <ul>{plan.tasks.map((item, index) => <li key={index}>{typeof item === 'string' ? item : String(object(item).title ?? object(item).description ?? object(item).task ?? printable(item))}</li>)}</ul>}</details>}
              <div className={`execution-summary ${running ? 'active' : ''}`} role="status" aria-live="polite"><span className={`task-dot ${run.status}`} /><span>{running ? currentSteps.length ? currentSteps.map(step => step.label).join(' · ') : '正在准备任务' : stateNames[run.status] ?? run.status}</span><small>{elapsed < 60 ? `${elapsed} 秒` : `${Math.floor(elapsed / 60)} 分 ${elapsed % 60} 秒`}</small></div>
              <details className="execution-steps"><summary><span>执行步骤</span><span>{steps.filter(step => step.status === 'succeeded').length} 个步骤已完成</span></summary>{steps.length ? <ol>{steps.map(step => <li key={`${step.id}-${step.attempt}`}><span className={`step-indicator ${step.status}`}><Icon name={step.status === 'succeeded' ? 'check' : 'clock'} size={13} /></span><span>{step.label}<small>{step.agent_name ?? ''}{step.attempt ? ` · 第 ${step.attempt} 轮修正` : ''}</small></span><span className="step-status">{stateNames[step.status] ?? step.status}</span></li>)}</ol> : <p className="muted">等待后端记录第一个步骤。</p>}</details>
              {running && activity.length > 0 && <p className="latest-progress">{activity.at(-1)?.message}</p>}
              {!running && summary && <section className={`task-result ${summary.tone}`}><h2>{summary.title}</h2><p>{summary.description}</p>{run.applied && <p className="success-text">修改已应用到待办示例项目。</p>}<div className="result-facts"><button onClick={() => setPanel('validation')}><Icon name="check" size={16} /><span>{test ? test.status === 'passed' ? `独立测试通过${test.testsRun != null ? ` · ${test.testsRun} 项` : ''}` : test.status === 'failed' ? '独立测试未通过' : '测试未完成' : '尚无完整测试结果'}</span></button>{changedFiles.length > 0 && <button onClick={() => setPanel('changes')}><Icon name="file" size={16} /><span>{changedFiles.length} 个文件有修改</span></button>}</div><div className="result-actions">{changedFiles.length > 0 && <button className="primary-button" onClick={() => { setPanel('changes'); setSourceMode(false) }}><Icon name="code" size={16} />查看修改</button>}{['failed', 'blocked'].includes(run.status) && <button className={changedFiles.length ? 'secondary-button' : 'primary-button'} disabled={busy} onClick={() => void resumeRun()}><Icon name="refresh" size={15} />{busy ? '正在恢复' : '恢复原任务'}</button>}<button className="secondary-button" onClick={() => setPanel('validation')}>查看验证结果</button></div>{['failed', 'blocked'].includes(run.status) && <p className="result-note">恢复会继续原需求的未完成步骤，并可能产生新的模型调用。</p>}{changedFiles.length > 0 && <p className="result-note">{activeTaskId === 'completion' ? run.applied ? '应用记录可在执行详情中查看。' : '修改仍保留在副本中，查看后可导出。' : '此任务保留固定基线，修改可导出保存。'}</p>}</section>}
              <button className="details-link" onClick={() => setPanel('activity')}><Icon name="clock" size={15} />查看完整执行记录 <span>{events.length}</span><Icon name="chevron" size={13} /></button>
              <div className="run-footnote">{typeof run.model_calls === 'number' && <span>{run.model_calls} 次模型请求</span>}{typeof run.model_tokens === 'number' && <span>{run.model_tokens.toLocaleString()} tokens{run.model_metrics_complete === false ? '（已知用量）' : ''}</span>}<span>修正 {run.attempt ?? 0} / 2 轮</span></div>
            </article>
            <div className="next-task"><div><strong>{running ? '任务会继续在后台运行' : '开始下一项需求'}</strong><p>新任务从所选示例基线开始，当前记录会保留。</p></div><button className="secondary-button" onClick={newTask}><Icon name="plus" size={16} />新任务</button></div>
          </div>}
        </main>
        {panel && <aside ref={detailPanel} className="detail-panel" aria-label="任务详情" role={narrow ? 'dialog' : undefined} aria-modal={narrow ? true : undefined} onKeyDown={event => {
          if (!narrow || event.key !== 'Tab') return
          const controls = [...event.currentTarget.querySelectorAll<HTMLElement>('button:not(:disabled), summary, [tabindex="0"]')].filter(element => element.getClientRects().length)
          const first = controls[0], last = controls.at(-1)
          if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
        }}><div className="detail-header"><nav aria-label="详情视图">{([{ id: 'changes', label: '修改' }, { id: 'validation', label: '验证' }, { id: 'activity', label: '过程' }, { id: 'project', label: '项目' }] as const).map(item => <button key={item.id} className={panel === item.id ? 'active' : ''} onClick={() => setPanel(item.id)} aria-current={panel === item.id ? 'page' : undefined}>{item.label}</button>)}</nav><button className="icon-button" aria-label="关闭详情" onClick={() => setPanel(null)}><Icon name="close" /></button></div><div className="detail-scroll">
          {panel === 'changes' && <>{changedFiles.length ? <><div className="detail-intro"><h2>{run?.applied ? '已应用的修改' : '待检查的修改'}</h2><p>{run?.status === 'succeeded' && test?.status === 'passed' ? '当前候选的独立测试和完整流程已通过。' : '尚未通过完整流程，请结合验证记录检查。'}{run?.mode === 'mock' ? '这是模拟生成的候选。' : ''}</p></div><div className="code-toggle"><button className={!sourceMode ? 'active' : ''} onClick={() => setSourceMode(false)}>修改差异</button><button className={sourceMode ? 'active' : ''} onClick={() => setSourceMode(true)}>完整代码</button></div>{changedFiles.map(file => <section key={file.path} className="file-section"><h3><Icon name="file" size={15} />{file.path}</h3><Code value={sourceMode ? file.after : file.diff} diff={!sourceMode} /></section>)}</> : <div className="panel-empty"><Icon name="code" size={25} /><h2>暂无代码修改</h2><p>{run?.workflow_id === 'review' ? '本次任务只进行审查，原始代码保持不变。' : running ? '生成的候选修改会显示在这里。' : '从一条开发需求开始，生成的修改将保留在独立副本中。'}</p></div>}</>}
          {panel === 'validation' && <><div className="detail-intro"><h2>验证结果</h2><p>{activeTask?.name ?? '待办示例'} · 固定独立验收</p></div>{test ? <section className="test-section"><div className="section-line"><h3>Docker 独立测试</h3><span className={test.status === 'passed' ? 'success-text' : 'warning-text'}>{test.status === 'passed' ? '通过' : test.status === 'failed' ? '未通过' : '未完成'}</span></div><p>{test.testsRun != null ? `实际执行 ${test.testsRun} 项测试` : '尚无完整测试计数'}{test.failures != null ? ` · ${test.failures} 项失败` : ''}{test.errors != null ? ` · ${test.errors} 项错误` : ''}</p><p className="muted">{test.round === 0 ? '首次候选' : `第 ${test.round} 轮修正`} · {test.isolated ? '隔离执行已确认' : '尚未确认隔离执行'}</p>{test.reason && <p>{test.reason}</p>}</section> : <div className="detail-intro"><p>当前候选尚无可确认的完整测试结果。执行受阻或模型服务失败不等于代码测试失败。</p></div>}{reviews.length > 0 && <p className="detail-intro muted">以下为本轮 Agent 的审查记录；当前候选是否通过，请结合独立测试确认。</p>}{reviews.map(step => <Review key={`${step.id}-${step.attempt}`} step={step} />)}<details className="raw-evidence"><summary>测试原始记录</summary>{events.filter(event => object(event.data).tool === 'run_acceptance' || event.type === 'validation').map(event => <EvidenceEvent key={event.id} event={event} />)}</details>{activeTask && <details className="raw-evidence"><summary>固定验收范围</summary><pre>{activeTask.requirement}</pre></details>}</>}
          {panel === 'activity' && <><div className="detail-intro"><h2>完整执行记录</h2><p>后端保存的分工、工具、验证与反馈记录。</p></div>{events.map(event => <EvidenceEvent event={event} key={event.id} />)}{run && <details className="raw-evidence"><summary>配置与步骤快照</summary><pre>{printable({ model: run.model_config, task: run.task, agents: run.agent_versions, snapshots: run.snapshots })}</pre></details>}{!events.length && <p className="detail-intro muted">任务开始后，真实执行记录会显示在这里。</p>}</>}
          {panel === 'project' && <><div className="detail-intro"><h2>{run ? '本次任务的项目基线' : '已连接的项目'}</h2><p>Python 待办示例 · todo.py</p><p className="muted">当前支持完成状态、批量编辑、优先级查询、JSON 导入导出四类需求。</p></div>{(run ? diffFiles.map(file => ({ path: file.path, content: file.before })) : projectFiles).map(file => <section className="file-section" key={file.path}><h3><Icon name="file" size={15} />{file.path}</h3><Code value={file.content} /></section>)}{run && !diffFiles.length && <p className="detail-intro muted">本次任务尚未保存可读取的项目副本。</p>}</>}
        </div>{panel === 'changes' && changedFiles.length > 0 && <div className="detail-actions"><button className="secondary-button" disabled={running} onClick={exportCandidate}><Icon name="download" size={15} />导出代码</button>{canApply && <button className="primary-button" onClick={() => setConfirmApply(true)}>应用到示例</button>}<span>{run?.applied ? '已应用' : activeTaskId === 'completion' ? '应用前需确认' : '基线保留 · 仅导出'}</span></div>}</aside>}
      </div>
    </div>
    <dialog ref={applyDialog} className="confirm-dialog" onCancel={event => { if (busy) event.preventDefault(); else setConfirmApply(false) }} onClose={() => setConfirmApply(false)} aria-labelledby="apply-title"><h2 id="apply-title">应用到待办示例？</h2><p>这会将已验证的候选写入目标文件，之后新任务会读取修改后的示例。</p><code>examples/todo/todo.py</code><p className="muted">若目标基线或候选已变化，系统会拒绝应用。</p><div className="dialog-actions"><button autoFocus className="secondary-button" disabled={busy} onClick={() => setConfirmApply(false)}>先不应用</button><button className="primary-button" disabled={busy || !canApply} onClick={() => void applyRun()}>{busy ? '正在应用…' : '确认应用修改'}</button></div></dialog>
  </div>
}
