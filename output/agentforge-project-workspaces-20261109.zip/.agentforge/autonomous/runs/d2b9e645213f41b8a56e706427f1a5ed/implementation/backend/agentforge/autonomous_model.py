"""Versioned model protocol for the autonomous controller and delegated tasks.

This is deliberately separate from the frozen, role-based experiment adapter.
Only proposed text edits cross this boundary. No model-created command is run.
"""
from __future__ import annotations

import asyncio
import ast
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import time
import uuid

from .runtime import RuntimeErrorSafe
from .storage import now
from .autonomous_sandbox import validate_bundle


class ModelBudgetExceeded(RuntimeErrorSafe):
    pass


class ModelProtocolError(RuntimeErrorSafe):
    pass


INTAKE_PROMPT = """Turn the user's software request into a small, testable Python project contract.
There are no task categories or predefined business roles. Infer practical public
function interfaces when the request permits; list assumptions rather than asking
unnecessary questions. Preserve every explicit requirement. This environment supports
Python standard-library modules with JSON function arguments/returns, no GUI, network,
package installation or persistent process/object state. If the actual requested
product cannot be represented faithfully within these limits, return needs_input;
do not silently replace a requested web app or external integration with a toy function.

For a supported request return exactly:
{"status":"ready","summary":"简短的中文范围说明","specification":"明确的模块名、函数签名、输入输出与边界行为，保留原需求","assumptions":["补充的合理假设"],"files":{"module.py":"unimplemented Python scaffold"},"acceptance":"unittest source"}
For unsupported or irreducibly ambiguous requests return exactly:
{"status":"needs_input","summary":"中文说明缺少什么或当前不支持什么","questions":["一个可以回答的具体问题"]}

files should contain only module docstrings, imports and plain public function
declarations. Each function body must be just optional docstring plus
raise NotImplementedError; do not implement the solution here. No decorators/classes.
Use simple module/function names. Acceptance is generated BEFORE implementation and
will be frozen. It is AI-generated coverage, not independent human assurance.
Write 3 to 8 focused unittest.TestCase test_ methods covering normal, edge and invalid
inputs relevant to the request. Import only unittest and `from bridge import call`.
EVERY test_ method must itself call call("module", "function", *args, **kwargs) and
assert real expected results or expected validation exceptions. Call returns JSON
values; tuples become lists. Never import candidate modules, inspect source, read files,
or assert mocked outputs. Never expect NotImplementedError or accept all exceptions.
The baseline scaffold MUST fail the tests. Use expected concrete values derived from
the stated specification. We will check baseline failure in Docker before delegating.
The original request, generated scope and all assumptions remain visible to the user.
Return one compact JSON object, no Markdown or tool calls. Use the user's language
for summaries/specification/assumptions/questions (Chinese for Chinese requests).
"""


CONTROLLER_PROMPT = """You are the main Agent of an autonomous Python development run.
Read the user's requirement, the current project, all task outcomes, and the latest
independent verification. You own the actual execution plan. There are no predefined
roles, business stages, or task categories. Choose a useful decomposition for THIS
requirement, name each delegated task, and give its worker concrete instructions.
Do not manufacture extra roles or parallelism for appearance. Tasks may investigate,
implement, or diagnose any relevant issue; a worker can return no file changes.
Dependencies and write scopes are enforced by the host. Every task ID must be new.
Dependencies may refer to existing successful tasks or tasks in the same dispatch.
Specify complete relative .py file paths in write_paths, including new files if needed.
Disjoint ready tasks may execute concurrently. Overlapping writes will be serialized.
Workers receive the current project and prior results; they propose full file contents.
Workers cannot run shell commands. The host provides independent Docker verification.
After each dependency-ready wave, you get control again. Use actual outcomes to
continue, cancel obsolete pending tasks, add replacement work, or request verification.
Failed tasks are not silently retried. Plan new tasks with new IDs when work is needed.
Do not claim a test passed based on a worker's summary. Only last_verification is test
evidence. Finish only when there are no pending tasks and independent verification
passed for the current candidate hash. If requirements are impossible within the
remaining budget, stop honestly. Do not modify or bypass acceptance or the runner.
Return ONE JSON object, no Markdown, no tools, in exactly one of these shapes:
{"action":"dispatch","summary":"why this plan fits the evidence","tasks":[{"id":"unique-id","title":"task name","instructions":"specific bounded assignment","depends_on":[],"write_paths":["module.py"]}]}
{"action":"continue","summary":"why the next ready wave remains useful"}
{"action":"cancel","summary":"why these pending tasks are obsolete","task_ids":["pending-id"]}
{"action":"verify","summary":"why independent tests should run now"}
{"action":"finish","summary":"what is complete, with evidence and limitations"}
{"action":"stop","summary":"specific blocker or unmet requirement"}
All decisions and outputs will be retained, including failures. A protocol retry only
repairs JSON/schema, not implementation; do not misrepresent it as a code correction.
Write summaries, task titles and explanations in the same language as the user's
request (Chinese for Chinese requests); normal code identifiers stay unchanged.
"""

WORKER_PROMPT = """You are a newly delegated Agent. Your identity and task are defined by
the main Agent's current assignment, not a predefined role. Read the requirement,
current project, assignment, dependencies, results, and real verification feedback.
Perform only the bounded assignment. You may propose changes only to the exact paths
in the assignment's write_paths. Return full contents for each changed file; omit
unchanged files. For analysis-only work return an empty files object and useful findings.
Use Python's standard library; there is no network or package install during tests.
No generated code runs on the host. You cannot run commands or edit the independent
acceptance suite, runner, or another worker's files. Do not claim to have run tests.
The host will apply allowed proposals and run Docker verification when the main Agent
requests it. Implement the requirement, not fabricated test results or test evasion.
Return ONE JSON object, no Markdown, no tools, exactly:
{"summary":"what you changed or discovered, and unresolved issues","files":{"relative/path.py":"complete file content"}}
Write the summary in the same language as the user's request, Chinese for Chinese requests.
"""


def _text(value, field, limit=8000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f"{field} must be a nonempty string of at most {limit} characters")


def _strings(value, field, limit=100):
    if not isinstance(value, list) or len(value) > limit or any(not isinstance(v, str) or not v or len(v) > 300 for v in value):
        raise ValueError(f"{field} must be an array of bounded nonempty strings")
    if len(value) != len(set(value)):
        raise ValueError(f"{field} must not contain duplicates")


def validate_decision(value):
    if not isinstance(value, dict):
        raise ValueError("decision must be an object")
    action = value.get("action")
    if action not in {"dispatch", "continue", "cancel", "verify", "finish", "stop"}:
        raise ValueError("action must be dispatch, continue, cancel, verify, finish, or stop")
    expected = {"action", "summary"} | ({"tasks"} if action == "dispatch" else {"task_ids"} if action == "cancel" else set())
    if set(value) != expected:
        raise ValueError("unexpected or missing decision fields")
    _text(value["summary"], "summary")
    if action == "cancel":
        _strings(value["task_ids"], "task_ids")
        if not value["task_ids"]:
            raise ValueError("cancel requires at least one task ID")
    if action == "dispatch":
        tasks = value["tasks"]
        if not isinstance(tasks, list) or not 1 <= len(tasks) <= 24:
            raise ValueError("dispatch requires 1 to 24 tasks")
        ids = set()
        for task in tasks:
            if not isinstance(task, dict) or set(task) != {"id", "title", "instructions", "depends_on", "write_paths"}:
                raise ValueError("each task needs id, title, instructions, depends_on, write_paths")
            _text(task["id"], "id", 80)
            _text(task["title"], "title", 200)
            _text(task["instructions"], "instructions", 16000)
            _strings(task["depends_on"], "depends_on")
            _strings(task["write_paths"], "write_paths", 32)
            if task["id"] in ids:
                raise ValueError("task IDs in one dispatch must be unique")
            ids.add(task["id"])
    return value


def validate_work(value):
    if not isinstance(value, dict) or set(value) != {"summary", "files"}:
        raise ValueError("worker output needs exactly summary and files")
    _text(value["summary"], "summary")
    files = value["files"]
    if not isinstance(files, dict) or len(files) > 32:
        raise ValueError("files must be an object with at most 32 entries")
    for path, content in files.items():
        _text(path, "file path", 300)
        if not isinstance(content, str) or len(content.encode("utf-8")) > 131072:
            raise ValueError("file content must be a string of at most 131072 bytes")
    if sum(len(content.encode("utf-8")) for content in files.values()) > 524288:
        raise ValueError("combined file proposal exceeds 524288 bytes")
    return value


def validate_intake(value):
    """Static structure checks only; generated Python is never executed here.

These checks reject empty/obviously self-fulfilling suites, not prove coverage.
The frozen suite must also fail the unimplemented scaffold in Docker.
"""
    if not isinstance(value, dict):
        raise ValueError("intake must be an object")
    status = value.get("status")
    if status == "needs_input":
        if set(value) != {"status", "summary", "questions"}:
            raise ValueError("needs_input requires exactly status,summary,questions")
        _text(value["summary"], "summary", 2000)
        _strings(value["questions"], "questions", 3)
        if not value["questions"]:
            raise ValueError("needs_input must ask a concrete question")
        return value
    if status != "ready" or set(value) != {"status", "summary", "specification", "assumptions", "files", "acceptance"}:
        raise ValueError("ready intake needs status,summary,specification,assumptions,files,acceptance")
    _text(value["summary"], "summary", 2000)
    _text(value["specification"], "specification", 6000)
    _strings(value["assumptions"], "assumptions", 12)
    try:
        validate_bundle({"requirement": value["specification"], "files": value["files"],
                         "acceptance": value["acceptance"], "provenance": {"kind": "natural"}})
    except RuntimeErrorSafe as exc:
        raise ValueError(str(exc)) from None
    functions = set()
    for path, content in value["files"].items():
        try:
            tree = ast.parse(content)
        except SyntaxError as exc:
            raise ValueError(f"Invalid scaffold syntax in {path}: {exc.msg}") from None
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)) or (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)):
                continue
            if not isinstance(node, ast.FunctionDef) or node.decorator_list:
                raise ValueError("Scaffold may contain only imports, docstrings and undecorated functions")
            body = list(node.body)
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
                body.pop(0)
            raised = body[0].exc if len(body) == 1 and isinstance(body[0], ast.Raise) else None
            exception = raised.func if isinstance(raised, ast.Call) else raised
            if not isinstance(exception, ast.Name) or exception.id != "NotImplementedError":
                raise ValueError("Scaffold functions must raise NotImplementedError without an implementation")
            functions.add((path.removesuffix(".py").replace("/", "."), node.name))
    if not functions:
        raise ValueError("Intake requires at least one unimplemented public function")
    try:
        suite = ast.parse(value["acceptance"])
    except SyntaxError as exc:
        raise ValueError("Invalid acceptance syntax: " + exc.msg) from None
    imports = [node for node in ast.walk(suite) if isinstance(node, (ast.Import, ast.ImportFrom))]
    if not any(isinstance(node, ast.ImportFrom) and node.module == "bridge"
               and any(alias.name == "call" and alias.asname is None for alias in node.names) for node in imports):
        raise ValueError("Acceptance must import from bridge import call")
    for node in imports:
        if isinstance(node, ast.Import):
            if any(alias.name != "unittest" or alias.asname for alias in node.names):
                raise ValueError("Acceptance may import only unittest and bridge.call")
        elif node.module != "bridge" or node.level or any(alias.name != "call" or alias.asname for alias in node.names):
            raise ValueError("Acceptance may import only unittest and bridge.call")
    methods = [node for cls in suite.body if isinstance(cls, ast.ClassDef)
               and any(isinstance(base, ast.Attribute) and isinstance(base.value, ast.Name)
                       and base.value.id == "unittest" and base.attr == "TestCase" for base in cls.bases)
               for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
    class_names = set()
    for cls in (node for node in suite.body if isinstance(node, ast.ClassDef)):
        if cls.name in class_names:
            raise ValueError("Acceptance class names must be unique")
        class_names.add(cls.name)
        test_names = [node.name for node in cls.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
        if len(test_names) != len(set(test_names)):
            raise ValueError("Acceptance test method names must be distinct within each class")
    if not 3 <= len(methods) <= 30:
        raise ValueError("Acceptance needs at least 3 distinct unittest test_ methods")
    for method in methods:
        calls = [node for node in ast.walk(method) if isinstance(node, ast.Call)]
        bridges = [node for node in calls if isinstance(node.func, ast.Name) and node.func.id == "call"]
        assertions = [node for node in calls if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
                      and node.func.value.id == "self" and node.func.attr.startswith("assert")]
        if not bridges or not assertions:
            raise ValueError("Every test method needs a direct bridge.call and an assertion")
        for call in bridges:
            if len(call.args) < 2 or any(not isinstance(arg, ast.Constant) or not isinstance(arg.value, str) for arg in call.args[:2]):
                raise ValueError("bridge.call module/function must be explicit string literals")
            if tuple(arg.value for arg in call.args[:2]) not in functions:
                raise ValueError("Acceptance refers to a function absent from the scaffold")
        for node in ast.walk(method):
            if isinstance(node, ast.Name) and node.id in {"NotImplementedError", "Exception", "BaseException"}:
                raise ValueError("Acceptance cannot treat unimplemented or arbitrary exceptions as success")
    return value


class AutonomousModel:
    """Real requests, explicit format retries, and one shared persisted run budget.

    Budget accounting reserves UTF-8 prompt bytes + output cap + 1024 overhead per
    outstanding request, a deliberately conservative estimate, not tokenization.
    Known provider usage replaces that reservation on completion. Unknown usage
    keeps the reservation charged, and metrics_complete stays false. A provider can
    report usage above the reservation; that excess is recorded and prevents further
    requests. This cannot promise an exact provider-side billing cap.
    """

    def __init__(self, runtime, store):
        self.runtime = runtime
        self.store = store
        self._locks = {}

    def _lock(self, run_id):
        return self._locks.setdefault(run_id, asyncio.Lock())

    def config(self, budget=None):
        budget = budget or {}
        return {"model": self.runtime.settings["model"], "base_url": self.runtime.settings["base_url"],
                "temperature": 0.1, "max_output_tokens": budget.get("max_output_tokens", 4096),
                "adapter_revision": "autonomous-2-intake", "contract_retries": 1,
                "min_request_interval": self.runtime.settings.get("min_request_interval", 0),
                "timeout_seconds": self.runtime.settings["timeout"]}

    async def decide(self, run, context):
        return await self._invoke(run, "main", None, CONTROLLER_PROMPT, context, validate_decision)

    async def prepare(self, run):
        return await self._invoke(run, "intake", None, INTAKE_PROMPT,
                                  {"requirement": run["requirement"], "project": {},
                                   "acceptance_origin": "model_generated"}, validate_intake)

    async def work(self, run, task, context):
        combined = {"assignment": task, "context": context}
        return await self._invoke(run, "worker", task.get("id"), WORKER_PROMPT, combined, validate_work)

    def _redact(self, value):
        secret = self.runtime.settings.get("api_key")
        if isinstance(value, str):
            return value.replace(secret, "[REDACTED]") if secret else value
        if isinstance(value, list):
            return [self._redact(v) for v in value]
        if isinstance(value, dict):
            return {self._redact(k): self._redact(v) for k, v in value.items()}
        return value

    def _write_record(self, path: Path, record):
        if path.is_symlink() or path.parent.is_symlink():
            raise RuntimeErrorSafe("Model evidence paths must not be symbolic links")
        temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            json.dump(self._redact(record), stream, ensure_ascii=False, indent=2)
        os.replace(temporary, path)

    def _metrics(self, run_id):
        current = self.store.run(run_id)
        if current is None:
            raise RuntimeErrorSafe("Autonomous run does not exist")
        return {"model_calls": 0, "tokens": 0, "budget_tokens": 0,
                "metrics_complete": True, "contract_retries": 0,
                "in_flight": 0, "reserved_tokens": 0, "unknown_usage_calls": 0,
                **current.get("model_metrics", {})}

    @staticmethod
    def _budget(run):
        value = {"max_calls": 30, "max_tokens": 300000, "max_output_tokens": 4096, **run.get("budget", {})}
        for key, minimum, maximum in (("max_calls", 1, 200), ("max_tokens", 1, 10000000), ("max_output_tokens", 256, 16384)):
            if type(value[key]) is not int or not minimum <= value[key] <= maximum:
                raise RuntimeErrorSafe(f"Invalid model budget: {key}")
        return value

    async def _request(self, run, role, task_id, messages, retry):
        run_id = run["id"]
        budget = self._budget(run)
        frozen = run.get("model_config", {})
        for key in ("model", "base_url"):
            if key in frozen and frozen[key] != self.runtime.settings[key]:
                raise RuntimeErrorSafe("Model configuration changed after the run was frozen")
        payload = {"model": self.runtime.settings["model"], "messages": messages,
                   "temperature": 0.1, "max_tokens": budget["max_output_tokens"],
                   "response_format": {"type": "json_object"}}
        reservation = len(json.dumps(messages, ensure_ascii=False).encode("utf-8")) + budget["max_output_tokens"] + 1024
        directory = self.runtime._run_dir(run_id) / "model_requests"
        if directory.is_symlink():
            raise RuntimeErrorSafe("Model evidence directory must not be a symbolic link")
        directory.mkdir(parents=True, exist_ok=True)
        started = time.monotonic()
        async with self._lock(run_id):
            metrics = self._metrics(run_id)
            if metrics["model_calls"] >= budget["max_calls"]:
                raise ModelBudgetExceeded("Model request budget exhausted; no additional request sent")
            if metrics["budget_tokens"] + metrics["reserved_tokens"] + reservation > budget["max_tokens"]:
                raise ModelBudgetExceeded("Insufficient token budget for a conservatively reserved request; no request sent")
            sequence = metrics["model_calls"] + 1
            path = directory / f"{sequence:04d}-{uuid.uuid4().hex[:12]}.json"
            record = {"sequence": sequence, "run_id": run_id, "role": role, "task_id": task_id,
                      "started_at": now(), "status": "in_flight", "format_retry": bool(retry),
                      "request": deepcopy(payload), "reserved_budget_tokens": reservation,
                      "usage_known": False, "evidence_revision": 1}
            self._write_record(path, record)
            metrics.update(model_calls=sequence, in_flight=metrics["in_flight"] + 1,
                           reserved_tokens=metrics["reserved_tokens"] + reservation, metrics_complete=False,
                           contract_retries=metrics["contract_retries"] + int(retry))
            self.store.update_run(run_id, model_metrics=metrics)
            self.store.event(run_id, "model_request", "Real model request started", task_id,
                             {"sequence": sequence, "role": role, "format_retry": bool(retry),
                              "evidence": str(path.relative_to(self.runtime._run_dir(run_id))).replace("\\", "/")})
        response = None
        failure = None
        try:
            response = await asyncio.to_thread(self.runtime._post, payload)
        except asyncio.CancelledError as exc:
            failure = exc
            record.update(status="cancelled", error="Local request cancelled; remote completion and usage unknown")
        except Exception as exc:
            failure = exc if isinstance(exc, RuntimeErrorSafe) else RuntimeErrorSafe("Model transport failed: " + type(exc).__name__)
            record.update(status="transport_failed", error=self._redact(str(failure)))
        else:
            record["status"] = "responded"
            # Never retain provider reasoning_content, credentials, or HTTP headers.
            if isinstance(response, dict):
                choices = response.get("choices")
                first = choices[0] if isinstance(choices, list) and choices else {}
                first = first if isinstance(first, dict) else {}
                message = first.get("message")
                message = message if isinstance(message, dict) else {}
                record["content"] = self._redact(message.get("content"))
                record["unexpected_tool_calls"] = bool(message.get("tool_calls"))
                record["finish_reason"] = self._redact(first.get("finish_reason"))
                usage = response.get("usage")
                record["usage"] = {k: v for k, v in usage.items() if k in {"prompt_tokens", "completion_tokens", "total_tokens"} and type(v) is int and v >= 0} if isinstance(usage, dict) else {}
        total = record.get("usage", {}).get("total_tokens")
        known = type(total) is int
        record.update(usage_known=known, finished_at=now(), duration_ms=round((time.monotonic() - started) * 1000))
        async with self._lock(run_id):
            metrics = self._metrics(run_id)
            metrics["in_flight"] -= 1
            metrics["reserved_tokens"] -= reservation
            metrics["tokens"] += total if known else 0
            metrics["budget_tokens"] += total if known else reservation
            metrics["unknown_usage_calls"] += int(not known)
            metrics["metrics_complete"] = metrics["unknown_usage_calls"] == 0 and metrics["in_flight"] == 0
            record["budget_charge_tokens"] = total if known else reservation
            self._write_record(path, record)
            self.store.update_run(run_id, model_metrics=metrics)
            self.store.event(run_id, "model_response", "Real model request completed" if failure is None else "Real model request failed", task_id,
                             {"sequence": sequence, "status": record["status"], "usage_known": known,
                              "tokens": total if known else None, "format_retry": bool(retry)})
        if failure is not None:
            raise failure
        return response, path, record

    async def _invoke(self, run, role, task_id, prompt, context, validator):
        if run.get("mode", "live") != "live":
            raise RuntimeErrorSafe("AutonomousModel is a real model adapter; mock mode is not implemented here")
        content = json.dumps({"requirement": run.get("requirement", ""), "context": context}, ensure_ascii=False)
        if len(content.encode("utf-8")) > 180000:
            raise RuntimeErrorSafe("Autonomous model context exceeds 180000 bytes; it was not silently truncated")
        messages = [{"role": "system", "content": prompt}, {"role": "user", "content": content}]
        for retry in range(2):
            response, path, record = await self._request(run, role, task_id, messages, retry)
            raw = record.get("content")
            try:
                if record.get("unexpected_tool_calls"):
                    raise ValueError("tool calls are not allowed by this protocol")
                if not isinstance(raw, str):
                    raise ValueError("message.content must be a JSON string")
                output = validator(json.loads(raw))
            except (ValueError, TypeError, KeyError) as exc:
                error = {"kind": "json_syntax" if isinstance(exc, json.JSONDecodeError) else "schema", "message": self._redact(str(exc))}
                record.update(status="protocol_failed", protocol_error=error, retry_scheduled=retry == 0,
                              content_sha256=hashlib.sha256((raw if isinstance(raw, str) else json.dumps(raw)).encode("utf-8")).hexdigest())
                self._write_record(path, record)
                self.store.event(run["id"], "format_error", "Model output failed JSON/schema validation; this is not a code failure", task_id,
                                 {"sequence": record["sequence"], "error": error, "retry_scheduled": retry == 0})
                if retry:
                    raise ModelProtocolError("Model output still violates the protocol after one recorded format retry") from None
                messages.append({"role": "assistant", "content": raw if isinstance(raw, str) else "null"})
                messages.append({"role": "user", "content": "Your previous response failed JSON/schema validation: " + json.dumps(error, ensure_ascii=False)
                                 + ". Return a fresh complete JSON object with exactly the requested fields. Do not use Markdown or tools. This is a format retry; do not claim tests ran or code was repaired."})
                continue
            record.update(status="accepted", output=self._redact(output))
            self._write_record(path, record)
            self.runtime._model_verified, self.runtime._health_cache = True, None
            return output
        raise ModelProtocolError("Unreachable autonomous model protocol state")
