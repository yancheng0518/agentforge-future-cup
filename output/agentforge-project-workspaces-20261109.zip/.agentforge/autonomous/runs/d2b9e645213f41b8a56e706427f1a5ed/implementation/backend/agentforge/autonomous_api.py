"""Separate API/data store for model-directed runs; legacy records stay untouched."""
import asyncio
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from .autonomous import AutonomousEngine
from .runtime import Runtime
from .storage import Store


class AutonomousRunInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    bundle: dict
    budget: dict = Field(default_factory=dict)


class AutonomousRequestInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    requirement: str = Field(min_length=1, max_length=8000)
    budget: dict = Field(default_factory=dict)


def mount_autonomous(app, root, data_dir):
    data_dir = data_dir / "autonomous"
    store = Store(data_dir / "agentforge.sqlite3")
    runtime = Runtime(root, data_dir)
    engine = AutonomousEngine(store, runtime)
    create_lock = asyncio.Lock()
    router = APIRouter(prefix="/api/autonomous")

    def require_run(run_id):
        run = store.run(run_id)
        if not run:
            raise HTTPException(404, "动态运行不存在")
        return run

    @router.post("/requests", status_code=201)
    async def create_request(body: AutonomousRequestInput):
        health = await runtime.health()
        if not health["model"]["configured"] or not health["sandbox"]["available"]:
            raise HTTPException(409, "需要真实模型配置和 Docker 才能启动；不会切换为模拟执行")
        async with create_lock:
            if sum(not task.done() for task in engine.tasks.values()) >= 2:
                raise HTTPException(429, "最多并发 2 个动态运行")
            try:
                run = engine.create_run_from_requirement(body.requirement, body.budget)
            except (ValueError, RuntimeError) as exc:
                raise HTTPException(422, str(exc)) from None
            engine.start(run["id"])
        return {key: value for key, value in run.items() if key != "bundle"}

    @router.post("/runs", status_code=201)
    async def create(body: AutonomousRunInput):
        health = await runtime.health()
        if not health["model"]["configured"] or not health["sandbox"]["available"]:
            raise HTTPException(409, "动态运行需要真实模型配置和 Docker；不会切换模拟或主机执行")
        async with create_lock:
            if sum(not task.done() for task in engine.tasks.values()) >= 2:
                raise HTTPException(429, "最多并发 2 个动态运行")
            try:
                run = engine.create_run(body.bundle, body.budget)
            except (ValueError, RuntimeError) as exc:
                raise HTTPException(422, str(exc)) from None
            engine.start(run["id"])
        return {k: v for k, v in run.items() if k != "bundle"}

    @router.get("/runs")
    async def list_runs():
        return [{k: v for k, v in run.items() if k != "bundle"} for run in store.runs()]

    @router.get("/runs/{run_id}")
    async def get_run(run_id: str):
        require_run(run_id)
        return engine.export(run_id)

    @router.get("/runs/{run_id}/candidate")
    async def candidate(run_id: str):
        require_run(run_id)
        try:
            return {"files": await engine.sandbox.read(run_id),
                    "sha256": await engine.sandbox.fingerprint(run_id)}
        except FileNotFoundError:
            raise HTTPException(409, "候选目录尚未准备完成") from None
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from None

    app.include_router(router)
    app.state.autonomous_engine = engine
    app.state.autonomous_store = store
    return engine
