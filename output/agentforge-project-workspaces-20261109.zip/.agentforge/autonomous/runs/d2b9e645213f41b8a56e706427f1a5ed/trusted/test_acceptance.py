import unittest
from bridge import call


class ExpenseReportTest(unittest.TestCase):
    def test_parse_expenses_reads_normal_rows(self):
        text = 'category,amount\n 餐饮 ,12.50\n"交通,出差",3.00\n\n餐饮,-2.50\n'
        self.assertEqual(call('csv_reader', 'parse_expenses', text), [
            {'category': '餐饮', 'amount_cents': 1250},
            {'category': '交通,出差', 'amount_cents': 300},
            {'category': '餐饮', 'amount_cents': -250},
        ])

    def test_parse_expenses_only_header_and_blank_lines(self):
        self.assertEqual(call('csv_reader', 'parse_expenses', 'category,amount\n\n\n'), [])

    def test_parse_expenses_rejects_bad_shape_header_and_amounts(self):
        cases = [
            'category,amount\n餐饮\n',
            'category,amount\n餐饮,1.00,x\n',
            'category,amount\n餐饮,NaN\n',
            'category,amount\n餐饮,Infinity\n',
            'category,amount\n餐饮,1.234\n',
            'category,amount\n餐饮,abc\n',
            'name,amount\n餐饮,1.00\n',
        ]
        for text in cases:
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    call('csv_reader', 'parse_expenses', text)

    def test_parse_expenses_rejects_blank_category(self):
        with self.assertRaises(ValueError):
            call('csv_reader', 'parse_expenses', 'category,amount\n   ,1.00\n')

    def test_summarize_groups_sorts_and_does_not_mutate(self):
        items = [
            {'category': '交通', 'amount_cents': 300},
            {'category': '餐饮', 'amount_cents': 1250},
            {'category': '餐饮', 'amount_cents': -250},
        ]
        snapshot = [
            {'category': '交通', 'amount_cents': 300},
            {'category': '餐饮', 'amount_cents': 1250},
            {'category': '餐饮', 'amount_cents': -250},
        ]
        self.assertEqual(call('report', 'summarize', items), [
            {'category': '餐饮', 'total_cents': 1000, 'count': 2},
            {'category': '交通', 'total_cents': 300, 'count': 1},
        ])
        self.assertEqual(items, snapshot)

    def test_summarize_empty_list(self):
        self.assertEqual(call('report', 'summarize', []), [])

    def test_build_report_combines_parse_and_summary(self):
        text = 'category,amount\n餐饮,12.50\n交通,3.00\n餐饮,-2.50\n'
        self.assertEqual(call('report', 'build_report', text), [
            {'category': '交通', 'total_cents': 300, 'count': 1},
            {'category': '餐饮', 'total_cents': 1000, 'count': 2},
        ])

    def test_build_report_propagates_parse_error(self):
        with self.assertRaises(ValueError):
            call('report', 'build_report', 'category,amount\n餐饮,invalid\n')
