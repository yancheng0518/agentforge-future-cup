import unittest
from bridge import call


class TestParseExpenses(unittest.TestCase):
    def test_basic_parse(self):
        text = "category,amount\n餐饮,12.50\n交通,3.00"
        result = call("csv_reader", "parse_expenses", text)
        self.assertEqual(result, [
            {"category": "餐饮", "amount_cents": 1250},
            {"category": "交通", "amount_cents": 300},
        ])

    def test_header_only(self):
        result = call("csv_reader", "parse_expenses", "category,amount\n")
        self.assertEqual(result, [])

    def test_negative_and_trim_and_quoted_comma(self):
        text = 'category,amount\n  餐饮 ,-2.50\n"食品,饮料",1.05\n'
        result = call("csv_reader", "parse_expenses", text)
        self.assertEqual(result, [
            {"category": "餐饮", "amount_cents": -250},
            {"category": "食品,饮料", "amount_cents": 105},
        ])

    def test_ignore_blank_lines(self):
        text = "category,amount\n\n餐饮,1.00\n   \n交通,2.00\n"
        result = call("csv_reader", "parse_expenses", text)
        self.assertEqual(result, [
            {"category": "餐饮", "amount_cents": 100},
            {"category": "交通", "amount_cents": 200},
        ])

    def test_empty_category_raises(self):
        with self.assertRaises(ValueError):
            call("csv_reader", "parse_expenses", "category,amount\n   ,1.00\n")

    def test_invalid_amount_raises(self):
        for bad in ["NaN", "Infinity", "abc", "1.234"]:
            with self.assertRaises(ValueError):
                call("csv_reader", "parse_expenses", "category,amount\n餐饮," + bad + "\n")

    def test_missing_or_extra_column_raises(self):
        with self.assertRaises(ValueError):
            call("csv_reader", "parse_expenses", "category,amount\n餐饮\n")
        with self.assertRaises(ValueError):
            call("csv_reader", "parse_expenses", "category,amount\n餐饮,1.00,extra\n")


class TestSummarize(unittest.TestCase):
    def test_summarize_sorted(self):
        items = [
            {"category": "餐饮", "amount_cents": 1250},
            {"category": "交通", "amount_cents": 300},
            {"category": "餐饮", "amount_cents": -250},
        ]
        result = call("report", "summarize", items)
        self.assertEqual(result, [
            {"category": "交通", "total_cents": 300, "count": 1},
            {"category": "餐饮", "total_cents": 1000, "count": 2},
        ])

    def test_summarize_empty(self):
        self.assertEqual(call("report", "summarize", []), [])

    def test_summarize_does_not_mutate(self):
        items = [{"category": "餐饮", "amount_cents": 100}]
        call("report", "summarize", items)
        self.assertEqual(items, [{"category": "餐饮", "amount_cents": 100}])


class TestBuildReport(unittest.TestCase):
    def test_build_report_example(self):
        text = "category,amount\n餐饮,12.50\n交通,3.00\n餐饮,-2.50\n"
        result = call("report", "build_report", text)
        self.assertEqual(result, [
            {"category": "交通", "total_cents": 300, "count": 1},
            {"category": "餐饮", "total_cents": 1000, "count": 2},
        ])

    def test_build_report_propagates_error(self):
        with self.assertRaises(ValueError):
            call("report", "build_report", "category,amount\n餐饮,NaN\n")


if __name__ == "__main__":
    unittest.main()
