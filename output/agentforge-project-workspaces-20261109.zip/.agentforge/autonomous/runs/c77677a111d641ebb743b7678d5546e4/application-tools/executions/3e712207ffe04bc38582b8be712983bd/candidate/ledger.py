"""Initial working project for a declared project-continuation experiment."""


def add_expense(entries, title, cents, category):
    if not isinstance(title, str) or not title.strip():
        raise ValueError('title must not be empty')
    if type(cents) is not int or cents <= 0:
        raise ValueError('cents must be a positive integer')
    if not isinstance(category, str) or not category.strip():
        raise ValueError('category must not be empty')
    result = [dict(item) for item in entries]
    result.append({'id': max((item['id'] for item in result), default=0) + 1,
                   'title': title.strip(), 'cents': cents, 'category': category.strip()})
    return result


def list_expenses(entries):
    return sorted((dict(item) for item in entries), key=lambda item: item['id'])


def summarize_expenses(entries):
    totals = {}
    total_cents = 0
    for item in entries:
        cents = item['cents']
        category = item['category']
        total_cents += cents
        bucket = totals.get(category)
        if bucket is None:
            totals[category] = {'category': category, 'total_cents': cents, 'count': 1}
        else:
            bucket['total_cents'] += cents
            bucket['count'] += 1
    categories = [totals[name] for name in sorted(totals)]
    return {'total_cents': total_cents, 'categories': categories}


def delete_expense(entries, expense_id):
    if type(expense_id) is not int or expense_id <= 0:
        raise ValueError('expense_id must be a positive integer')
    result = []
    found = False
    for item in entries:
        if item['id'] == expense_id:
            found = True
            continue
        result.append(dict(item))
    if not found:
        raise KeyError(expense_id)
    return result
