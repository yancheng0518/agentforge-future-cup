"""Word frequency report utilities."""

from collections import Counter

from text_tools import tokenize


def _validate_limit(limit):
    """Validate limit: None or non-negative int (bool excluded), else ValueError."""
    if limit is None:
        return
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
        raise ValueError("limit must be None or a non-negative integer")


def summarize(text, limit=None):
    """Return word counts sorted by count desc then word asc, truncated by limit."""
    _validate_limit(limit)
    counts = Counter(tokenize(text))
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    if limit is not None:
        ordered = ordered[:limit]
    return [{"word": word, "count": count} for word, count in ordered]


def build_report(text, limit=None):
    """Return total_words, unique_words and summarized items."""
    _validate_limit(limit)
    tokens = tokenize(text)
    return {
        "total_words": len(tokens),
        "unique_words": len(set(tokens)),
        "items": summarize(text, limit),
    }
