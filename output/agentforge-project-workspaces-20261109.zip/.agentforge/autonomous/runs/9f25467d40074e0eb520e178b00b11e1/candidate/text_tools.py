"""Text tokenization utilities."""

import re

_WORD_RE = re.compile(r"[A-Za-z]+")


def tokenize(text):
    """Return lowercase ASCII-letter words from text."""
    return [match.lower() for match in _WORD_RE.findall(text)]
