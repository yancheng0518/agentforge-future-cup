import unittest
from bridge import call


class TestTokenize(unittest.TestCase):
    def test_mixed_example(self):
        self.assertEqual(
            call("text_tools", "tokenize", "Hi, HI! a2B 中文 cafe"),
            ["hi", "hi", "a", "b", "cafe"],
        )

    def test_empty(self):
        self.assertEqual(call("text_tools", "tokenize", ""), [])

    def test_only_separators(self):
        self.assertEqual(call("text_tools", "tokenize", "123 !? 中文"), [])


class TestSummarize(unittest.TestCase):
    def test_sorted_counts(self):
        self.assertEqual(
            call("word_report", "summarize", "red blue red green blue"),
            [
                {"word": "blue", "count": 2},
                {"word": "red", "count": 2},
                {"word": "green", "count": 1},
            ],
        )

    def test_limit_zero(self):
        self.assertEqual(call("word_report", "summarize", "a b a", 0), [])

    def test_limit_truncates(self):
        self.assertEqual(
            call("word_report", "summarize", "red blue red green blue", 1),
            [{"word": "blue", "count": 2}],
        )

    def test_negative_limit_raises(self):
        with self.assertRaises(ValueError):
            call("word_report", "summarize", "a b", -1)

    def test_bool_limit_raises(self):
        with self.assertRaises(ValueError):
            call("word_report", "summarize", "a b", True)

    def test_non_int_limit_raises(self):
        with self.assertRaises(ValueError):
            call("word_report", "summarize", "a b", 1.5)


class TestBuildReport(unittest.TestCase):
    def test_example_with_limit(self):
        self.assertEqual(
            call("word_report", "build_report", "red blue red green blue", 1),
            {
                "total_words": 5,
                "unique_words": 3,
                "items": [{"word": "blue", "count": 2}],
            },
        )

    def test_empty(self):
        self.assertEqual(
            call("word_report", "build_report", ""),
            {"total_words": 0, "unique_words": 0, "items": []},
        )

    def test_invalid_limit_raises(self):
        with self.assertRaises(ValueError):
            call("word_report", "build_report", "a b", -2)
