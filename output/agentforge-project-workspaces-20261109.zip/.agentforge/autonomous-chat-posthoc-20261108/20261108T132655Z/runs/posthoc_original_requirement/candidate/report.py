"""支出汇总与报告模块。"""

from csv_reader import parse_expenses


def summarize(items):
    """按类别汇总整数分，返回按 category 升序的列表。"""
    totals = {}
    counts = {}
    for item in items:
        category = item["category"]
        amount_cents = item["amount_cents"]
        totals[category] = totals.get(category, 0) + amount_cents
        counts[category] = counts.get(category, 0) + 1
    return [
        {
            "category": category,
            "total_cents": totals[category],
            "count": counts[category],
        }
        for category in sorted(totals)
    ]


def build_report(text):
    """组合 CSV 解析与汇总，返回按类别升序的汇总列表。"""
    return summarize(parse_expenses(text))
