"""CSV 支出解析模块。"""

import csv
import io
from decimal import Decimal, InvalidOperation

_REQUIRED_COLUMNS = ("category", "amount")


def _parse_amount_cents(raw, line_no):
    """将金额文本精确换算为整数分，非法时抛 ValueError。"""
    text = raw.strip()
    if not text:
        raise ValueError("第 %d 行金额为空" % line_no)
    try:
        value = Decimal(text)
    except InvalidOperation:
        raise ValueError("第 %d 行金额非法: %r" % (line_no, raw))
    if not value.is_finite():
        raise ValueError("第 %d 行金额非法: %r" % (line_no, raw))
    if value.as_tuple().exponent < -2:
        raise ValueError("第 %d 行金额小数位超过两位: %r" % (line_no, raw))
    cents = value * 100
    if cents != cents.to_integral_value():
        raise ValueError("第 %d 行金额无法精确换算为分: %r" % (line_no, raw))
    return int(cents)


def parse_expenses(text):
    """解析 CSV 文本，返回 [{"category": str, "amount_cents": int}]。"""
    reader = csv.reader(io.StringIO(text, newline=""))
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("CSV 为空，缺少表头")

    header_names = [name.strip() for name in header]
    if len(header_names) != len(_REQUIRED_COLUMNS) or sorted(header_names) != sorted(
        _REQUIRED_COLUMNS
    ):
        raise ValueError(
            "表头必须恰好包含 category 与 amount 两列，实际为: %r" % (header,)
        )
    category_index = header_names.index("category")
    amount_index = header_names.index("amount")
    column_count = len(header_names)

    items = []
    for line_no, row in enumerate(reader, start=2):
        if all(field.strip() == "" for field in row):
            continue
        if len(row) != column_count:
            raise ValueError(
                "第 %d 行字段数 %d 与表头列数 %d 不符" % (line_no, len(row), column_count)
            )
        category = row[category_index].strip()
        if not category:
            raise ValueError("第 %d 行类别为空" % line_no)
        amount_cents = _parse_amount_cents(row[amount_index], line_no)
        items.append({"category": category, "amount_cents": amount_cents})
    return items
