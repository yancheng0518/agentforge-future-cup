"""Maintainer post-hoc original-requirement checks; zero model calls, Docker only."""
import asyncio
from datetime import datetime,timezone
import argparse,ast,hashlib,json,re
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'backend'))
from agentforge.runtime import Runtime
from agentforge.autonomous_sandbox import AutonomousSandbox
SOURCE_ID='d2b9e645213f41b8a56e706427f1a5ed'
SOURCE=ROOT/'.agentforge/autonomous/runs'/SOURCE_ID
SUITE=r'''import unittest
from bridge import call

class OriginalRequirementTests(unittest.TestCase):
    def test_summarize_unicode_category_ascending(self):
        rows = [{'category': '餐饮', 'amount_cents': 1250}, {'category': '交通', 'amount_cents': 300}, {'category': '餐饮', 'amount_cents': -250}]
        self.assertEqual(call('report', 'summarize', rows), [
            {'category': '交通', 'total_cents': 300, 'count': 1},
            {'category': '餐饮', 'total_cents': 1000, 'count': 2}])

    def test_summarize_uses_python_string_order_for_mixed_categories(self):
        categories = ['餐饮', '交通', '😀', 'é', 'A']
        rows = [{'category': category, 'amount_cents': 1} for category in categories]
        result = call('report', 'summarize', rows)
        self.assertEqual([item['category'] for item in result], sorted(categories))

    def test_build_report_is_parse_then_summarize(self):
        text = 'category,amount\n餐饮,12.50\n交通,3.00\n餐饮,-2.50\n'
        parsed = call('csv_reader', 'parse_expenses', text)
        self.assertEqual(call('report', 'build_report', text), call('report', 'summarize', parsed))

    def test_build_report_original_example(self):
        text = 'category,amount\n餐饮,12.50\n交通,3.00\n餐饮,-2.50\n'
        self.assertEqual(call('report', 'build_report', text), [
            {'category': '交通', 'total_cents': 300, 'count': 1},
            {'category': '餐饮', 'total_cents': 1000, 'count': 2}])

    def test_summarize_empty(self):
        self.assertEqual(call('report', 'summarize', []), [])

    def test_parse_exact_cents_and_trim(self):
        self.assertEqual(call('csv_reader', 'parse_expenses', 'category,amount\n  餐饮  ,12.50\n交通,-2.50\n'), [
            {'category': '餐饮', 'amount_cents': 1250}, {'category': '交通', 'amount_cents': -250}])

    def test_csv_quoted_category(self):
        self.assertEqual(call('csv_reader', 'parse_expenses', 'category,amount\n"餐饮,招待",0.01\n'), [
            {'category': '餐饮,招待', 'amount_cents': 1}])

    def test_reject_extra_column(self):
        with self.assertRaises(ValueError):
            call('csv_reader', 'parse_expenses', 'category,amount\n交通,3.00,extra\n')
'''

def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()

async def main(source_id=SOURCE_ID, expected_status='failed'):
    global SOURCE_ID, SOURCE
    if not re.fullmatch('[0-9a-f]{32}',source_id):raise ValueError('Source run ID must be a hex UUID')
    SOURCE_ID=source_id
    SOURCE=ROOT/'.agentforge/autonomous/runs'/source_id
    ast.parse(SUITE)  # Static syntax check only, never execute candidate or tests on host.
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    data_dir=Path(__file__).resolve().parent/stamp
    data_dir.mkdir(exist_ok=False)
    (data_dir/'verify_original_requirement.py').write_bytes(Path(__file__).read_bytes())
    watched=[*sorted((SOURCE/'candidate').rglob('*.py')),*sorted((SOURCE/'trusted').rglob('*.py')),*sorted((SOURCE/'runner').rglob('*.py')),SOURCE/'bundle.json',SOURCE/'autonomous_manifest.json']
    before={p.relative_to(SOURCE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in watched}
    files={p.relative_to(SOURCE/'candidate').as_posix():p.read_text(encoding='utf-8') for p in sorted((SOURCE/'candidate').rglob('*.py'))}
    requirement=(ROOT/'output/autonomous-chat-20261108/ui-request.txt').read_text(encoding='utf-8-sig')
    original_export=json.loads((SOURCE/'evidence.json').read_text(encoding='utf-8'))
    if original_export['run']['requirement'].strip()!=requirement.strip():raise RuntimeError('Source run uses a different user requirement')
    expected_hash=original_export['run']['verified_hash']
    if sha(canonical(files))!=expected_hash:raise RuntimeError('Original candidate does not match recorded final hash')
    run_id='posthoc_original_requirement'
    runtime=Runtime(ROOT,data_dir);sandbox=AutonomousSandbox(runtime)
    bundle={'requirement':requirement,'files':files,'acceptance':SUITE,'provenance':{
        'kind':'natural','acceptance_origin':'maintainer_posthoc','category':'posthoc_requirement_check',
        'origin_run_id':SOURCE_ID,'origin_candidate_sha256':expected_hash,
        'description':'Unmodified real-model candidate copy; original-request checks only; no seeded defect; no model calls.'}}
    await sandbox.prepare(run_id,bundle)
    result=await sandbox.test(run_id)
    after={p.relative_to(SOURCE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in watched}
    evidence={'category':'posthoc_requirement_check','model_mode':'none','model_calls':0,'origin_run_id':SOURCE_ID,
        'origin_candidate_sha256':expected_hash,'original_request_sha256':sha(requirement),
        'original_files_sha256_before':before,'original_files_sha256_after':after,'original_files_unchanged':before==after,
        'run_id':run_id,'result':result,'interpretation':'Independent post-hoc checks of the original requirement; inspect actual outcomes without relying on generated-test pass claims.'}
    (data_dir/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'evidence':str(data_dir/'evidence.json'),'status':result['status'],'test_count':result['test_count'],'attestation':result.get('attestation'),'isolated':result['isolated'],'origin_candidate_sha256':expected_hash,'original_files_unchanged':before==after,'model_calls':0},ensure_ascii=True),flush=True)
    return 0 if result['status']==expected_status and result['isolated'] and before==after else 2

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-run',default='d2b9e645213f41b8a56e706427f1a5ed')
    parser.add_argument('--expected-status',choices=['passed','failed'],default='failed')
    args=parser.parse_args()
    raise SystemExit(asyncio.run(main(args.source_run,args.expected_status)))
