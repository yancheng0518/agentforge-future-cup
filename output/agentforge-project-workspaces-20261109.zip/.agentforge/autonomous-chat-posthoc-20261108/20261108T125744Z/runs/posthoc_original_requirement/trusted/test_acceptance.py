import unittest
from bridge import call

class OriginalRequirementTests(unittest.TestCase):
    def test_summarize_unicode_category_ascending(self):
        rows = [{'category': '餐饮', 'amount_cents': 1250}, {'category': '交通', 'amount_cents': 300}, {'category': '餐饮', 'amount_cents': -250}]
        self.assertEqual(call('report', 'summarize', rows), [
            {'category': '交通', 'total_cents': 300, 'count': 1},
            {'category': '餐饮', 'total_cents': 1000, 'count': 2}])

    def test_summarize_uses_python_string_order_for_mixed_categories(self):
        categories = ['餐饮', '交通', '😀', 'é', 'A']
        rows = [{'category': category, 'amount_cents': 1} for category in categories]
        result = call('report', 'summarize', rows)
        self.assertEqual([item['category'] for item in result], sorted(categories))

    def test_build_report_is_parse_then_summarize(self):
        text = 'category,amount\n餐饮,12.50\n交通,3.00\n餐饮,-2.50\n'
        parsed = call('csv_reader', 'parse_expenses', text)
        self.assertEqual(call('report', 'build_report', text), call('report', 'summarize', parsed))

    def test_build_report_original_example(self):
        text = 'category,amount\n餐饮,12.50\n交通,3.00\n餐饮,-2.50\n'
        self.assertEqual(call('report', 'build_report', text), [
            {'category': '交通', 'total_cents': 300, 'count': 1},
            {'category': '餐饮', 'total_cents': 1000, 'count': 2}])

    def test_summarize_empty(self):
        self.assertEqual(call('report', 'summarize', []), [])

    def test_parse_exact_cents_and_trim(self):
        self.assertEqual(call('csv_reader', 'parse_expenses', 'category,amount\n  餐饮  ,12.50\n交通,-2.50\n'), [
            {'category': '餐饮', 'amount_cents': 1250}, {'category': '交通', 'amount_cents': -250}])

    def test_csv_quoted_category(self):
        self.assertEqual(call('csv_reader', 'parse_expenses', 'category,amount\n"餐饮,招待",0.01\n'), [
            {'category': '餐饮,招待', 'amount_cents': 1}])

    def test_reject_extra_column(self):
        with self.assertRaises(ValueError):
            call('csv_reader', 'parse_expenses', 'category,amount\n交通,3.00,extra\n')
