"""支出汇总与报表模块。"""

from csv_reader import parse_expenses


def _category_sort_key(category):
    """为 summarize 提供确定性的类别排序键。

    可编码为 GBK 的类别按 GBK 字节序排列（常用汉字近似拼音顺序），
    无法编码的类别回退为按 Unicode 码点排列。
    """
    try:
        return (0, category.encode("gbk"))
    except UnicodeEncodeError:
        return (1, category)


def summarize(items):
    """按类别汇总整数分并返回排序后的结果。

    按 ``category`` 原值聚合 ``amount_cents``，不修改传入的列表或字典，
    返回新的列表，每项为
    ``{"category": 类别, "total_cents": 总分, "count": 条数}``。
    空输入返回 ``[]``。
    """
    totals = {}
    counts = {}

    for item in items:
        category = item["category"]
        amount_cents = int(item["amount_cents"])

        if category in totals:
            totals[category] += amount_cents
            counts[category] += 1
        else:
            totals[category] = amount_cents
            counts[category] = 1

    return [
        {
            "category": category,
            "total_cents": totals[category],
            "count": counts[category],
        }
        for category in sorted(totals, key=_category_sort_key)
    ]


def build_report(text):
    """解析 CSV 并生成按类别汇总的报表。

    先调用 ``parse_expenses(text)`` 再调用 ``summarize``，最后按 category
    的默认 Unicode 码点升序返回结果；解析错误以 ``ValueError`` 原样传播。
    """
    result = summarize(parse_expenses(text))
    return sorted(result, key=lambda item: item["category"])
