"""CSV 支出解析模块。"""

import csv
import io
import re
from decimal import Decimal


_HEADER = ["category", "amount"]
_AMOUNT_RE = re.compile(r"-?\d+(?:\.\d{1,2})?")


def parse_expenses(text):
    """解析包含 category、amount 两列的 CSV 文本。

    返回按输入数据行顺序排列的 ``[{"category": str, "amount_cents": int}]``。
    表头错误、列数不符、类别为空或金额非法时抛出 ``ValueError``。
    """
    try:
        rows = list(csv.reader(io.StringIO(text), strict=True))
    except csv.Error as exc:
        raise ValueError("CSV 格式错误: {0}".format(exc)) from exc

    if not rows:
        raise ValueError("缺少表头 category,amount")

    if rows[0] != _HEADER:
        raise ValueError("表头必须精确为 category,amount")

    items = []
    for row in rows[1:]:
        if not row or all(field.strip() == "" for field in row):
            continue

        if len(row) != 2:
            raise ValueError("每行必须恰好包含 category、amount 两列")

        category = row[0].strip()
        amount_text = row[1].strip()

        if not category:
            raise ValueError("category 不能为空")

        if _AMOUNT_RE.fullmatch(amount_text) is None:
            raise ValueError("非法金额: {0!r}".format(amount_text))

        amount_cents = int(Decimal(amount_text) * 100)
        items.append({"category": category, "amount_cents": amount_cents})

    return items
