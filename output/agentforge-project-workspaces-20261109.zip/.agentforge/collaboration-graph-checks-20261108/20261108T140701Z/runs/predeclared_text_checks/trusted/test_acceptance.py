import unittest
from bridge import call

class TextReportChecks(unittest.TestCase):
    def test_tokenize_exact_ascii_rules(self):
        self.assertEqual(call('text_tools', 'tokenize', 'Hi, HI! a2B 中文 cafe'), ['hi', 'hi', 'a', 'b', 'cafe'])

    def test_tokenize_empty_and_unicode_separators(self):
        self.assertEqual(call('text_tools', 'tokenize', ''), [])
        self.assertEqual(call('text_tools', 'tokenize', 'café中文X_42Y'), ['caf', 'x', 'y'])

    def test_counts_and_ties(self):
        self.assertEqual(call('word_report', 'summarize', 'red blue red green blue'), [
            {'word': 'blue', 'count': 2}, {'word': 'red', 'count': 2}, {'word': 'green', 'count': 1}])

    def test_limits(self):
        self.assertEqual(call('word_report', 'summarize', 'b a b a c', limit=1), [{'word': 'a', 'count': 2}])
        self.assertEqual(call('word_report', 'summarize', 'x x y', limit=0), [])
        self.assertEqual(call('word_report', 'summarize', 'x', limit=9), [{'word': 'x', 'count': 1}])

    def test_invalid_limits(self):
        for limit in [-1, True, False, 1.5, '2']:
            with self.subTest(limit=limit):
                with self.assertRaises(ValueError):
                    call('word_report', 'summarize', 'x', limit=limit)
                with self.assertRaises(ValueError):
                    call('word_report', 'build_report', 'x', limit=limit)

    def test_report_totals_before_limit(self):
        self.assertEqual(call('word_report', 'build_report', 'red blue red green blue', limit=1), {
            'total_words': 5, 'unique_words': 3, 'items': [{'word': 'blue', 'count': 2}]})

    def test_report_zero_limit_keeps_totals(self):
        self.assertEqual(call('word_report', 'build_report', 'Hi hi world', limit=0), {
            'total_words': 3, 'unique_words': 2, 'items': []})

    def test_empty_report(self):
        self.assertEqual(call('word_report', 'summarize', ''), [])
        self.assertEqual(call('word_report', 'build_report', ''), {
            'total_words': 0, 'unique_words': 0, 'items': []})
