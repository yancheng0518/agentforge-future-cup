"""TodoStore with versioned JSON export and atomic import/merge.

Base behavior (add/complete/list) is preserved. JSON merge features are
implemented here: export_json() and import_json(payload, collision).
"""

import json


_ALLOWED_COLLISIONS = ("error", "replace", "skip")


def _is_exact_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _is_exact_bool(value):
    return isinstance(value, bool)


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def add(self, title):
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must not be empty")
        task = {"id": self._next_id, "title": title.strip(), "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def export_json(self):
        tasks = [
            {"id": task["id"], "title": task["title"], "completed": task["completed"]}
            for task in self._tasks
        ]
        return json.dumps({"version": 1, "tasks": tasks})

    def import_json(self, payload, collision="error"):
        if not isinstance(collision, str) or collision not in _ALLOWED_COLLISIONS:
            raise ValueError("invalid collision mode")

        if not isinstance(payload, str):
            raise ValueError("payload must be a JSON string")
        try:
            document = json.loads(payload)
        except (ValueError, TypeError):
            raise ValueError("payload is not valid JSON")

        if not isinstance(document, dict):
            raise ValueError("top-level JSON must be an object")
        if set(document.keys()) != {"version", "tasks"}:
            raise ValueError("top-level must contain exactly version and tasks")

        version = document["version"]
        if not _is_exact_int(version) or version != 1:
            raise ValueError("version must be the integer 1")

        raw_tasks = document["tasks"]
        if not isinstance(raw_tasks, list):
            raise ValueError("tasks must be a list")

        validated = []
        seen_ids = set()
        for item in raw_tasks:
            if not isinstance(item, dict):
                raise ValueError("each task must be an object")
            if set(item.keys()) != {"id", "title", "completed"}:
                raise ValueError("each task must contain exactly id, title, completed")

            task_id = item["id"]
            if not _is_exact_int(task_id) or task_id <= 0:
                raise ValueError("id must be a positive integer")

            title = item["title"]
            if not isinstance(title, str):
                raise ValueError("title must be a string")
            stripped = title.strip()
            if not stripped:
                raise ValueError("title must not be empty")

            completed = item["completed"]
            if not _is_exact_bool(completed):
                raise ValueError("completed must be a boolean")

            if task_id in seen_ids:
                raise ValueError("duplicate id in payload")
            seen_ids.add(task_id)

            validated.append({"id": task_id, "title": stripped, "completed": completed})

        existing_ids = {task["id"] for task in self._tasks}

        if collision == "error":
            for task in validated:
                if task["id"] in existing_ids:
                    raise ValueError("id already exists")

        inserted = 0
        updated = 0
        skipped = 0

        if collision == "replace":
            by_id = {task["id"]: task for task in self._tasks}
            for task in validated:
                if task["id"] in by_id:
                    by_id[task["id"]]["title"] = task["title"]
                    by_id[task["id"]]["completed"] = task["completed"]
                    updated += 1
                else:
                    self._tasks.append(dict(task))
                    inserted += 1
        elif collision == "skip":
            for task in validated:
                if task["id"] in existing_ids:
                    skipped += 1
                else:
                    self._tasks.append(dict(task))
                    inserted += 1
        else:  # error
            for task in validated:
                self._tasks.append(dict(task))
                inserted += 1

        if self._tasks:
            max_id = max(task["id"] for task in self._tasks)
            if self._next_id <= max_id:
                self._next_id = max_id + 1

        return {"inserted": inserted, "updated": updated, "skipped": skipped}
