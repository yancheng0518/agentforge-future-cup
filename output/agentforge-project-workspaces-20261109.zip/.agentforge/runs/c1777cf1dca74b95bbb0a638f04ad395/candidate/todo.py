"""TodoStore with versioned JSON export and atomic import/merge."""

import json


_ALLOWED_COLLISIONS = ("error", "replace", "skip")


def _is_exact_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _is_exact_bool(value):
    return isinstance(value, bool)


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def add(self, title):
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must not be empty")
        task = {"id": self._next_id, "title": title.strip(), "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def export_json(self):
        payload = {
            "version": 1,
            "tasks": [
                {
                    "id": task["id"],
                    "title": task["title"],
                    "completed": task["completed"],
                }
                for task in self._tasks
            ],
        }
        return json.dumps(payload, ensure_ascii=False)

    def import_json(self, payload, collision="error"):
        if not isinstance(collision, str) or collision not in _ALLOWED_COLLISIONS:
            raise ValueError("collision must be one of 'error', 'replace', 'skip'")

        if not isinstance(payload, str):
            raise ValueError("payload must be a JSON string")

        try:
            document = json.loads(payload)
        except (ValueError, TypeError) as exc:
            raise ValueError("payload is not valid JSON") from exc

        if not isinstance(document, dict):
            raise ValueError("top-level JSON value must be an object")
        if set(document.keys()) != {"version", "tasks"}:
            raise ValueError("top-level object must contain exactly 'version' and 'tasks'")

        version = document["version"]
        if not _is_exact_int(version) or version != 1:
            raise ValueError("version must be the integer 1")

        raw_tasks = document["tasks"]
        if not isinstance(raw_tasks, list):
            raise ValueError("tasks must be a list")

        validated = []
        seen_ids = set()
        for item in raw_tasks:
            if not isinstance(item, dict):
                raise ValueError("each task must be an object")
            if set(item.keys()) != {"id", "title", "completed"}:
                raise ValueError("each task must contain exactly 'id', 'title', 'completed'")

            task_id = item["id"]
            if not _is_exact_int(task_id) or task_id <= 0:
                raise ValueError("task id must be a positive integer")

            title = item["title"]
            if not isinstance(title, str):
                raise ValueError("task title must be a string")
            stripped_title = title.strip()
            if not stripped_title:
                raise ValueError("task title must not be empty")

            completed = item["completed"]
            if not _is_exact_bool(completed):
                raise ValueError("task completed must be a boolean")

            if task_id in seen_ids:
                raise ValueError("duplicate task id in payload")
            seen_ids.add(task_id)

            validated.append({
                "id": task_id,
                "title": stripped_title,
                "completed": completed,
            })

        existing_by_id = {task["id"]: task for task in self._tasks}

        if collision == "error":
            for item in validated:
                if item["id"] in existing_by_id:
                    raise ValueError("task id already exists: %r" % (item["id"],))

        inserted = 0
        updated = 0
        skipped = 0
        new_tasks = []

        for item in validated:
            existing = existing_by_id.get(item["id"])
            if existing is None:
                new_tasks.append({
                    "id": item["id"],
                    "title": item["title"],
                    "completed": item["completed"],
                })
                inserted += 1
            elif collision == "replace":
                existing["title"] = item["title"]
                existing["completed"] = item["completed"]
                updated += 1
            else:  # skip
                skipped += 1

        self._tasks.extend(new_tasks)

        if new_tasks:
            max_id = max(task["id"] for task in self._tasks)
            if self._next_id <= max_id:
                self._next_id = max_id + 1

        return {"inserted": inserted, "updated": updated, "skipped": skipped}
