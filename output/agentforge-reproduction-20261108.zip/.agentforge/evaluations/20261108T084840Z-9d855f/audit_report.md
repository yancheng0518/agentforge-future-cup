# First preregistered batch: evidence audit

This report is an additional read-only audit. Original preregistration, summary and all eight trial exports are preserved.

Eight real-model trials completed: **6 candidates passed Docker 10/10; 2 workflows succeeded; 6 workflows failed**. Four failures occurred at static inspection after the same candidate had passed Docker. Two priority-query trials stopped before a candidate reached Docker.

**Natural code-test failures: 0. Automatic code-repair sequences: 0.** This batch does not demonstrate a natural-failure repair success, and no model defect was injected.

Observed model usage: **68 requests, 466,512 total tokens**. All runs report complete usage, independently reconciled with their agent events. This is token usage, not a billing calculation.

## Per-trial outcomes

- 01-completion-r1: Docker 10/10 passed; workflow failed; failed agent node round-0/verify/inspect; 8 requests; 27,691 tokens; 32.149s. [Evidence](trials/01-completion-r1/evidence.json)
- 02-bulk_edit-r1: Docker 10/10 passed; workflow succeeded; failed agent node none; 13 requests; 96,286 tokens; 60.202s. [Evidence](trials/02-bulk_edit-r1/evidence.json)
- 03-priority_query-r1: Docker execution not observed; workflow failed; failed agent node plan; 2 requests; 10,043 tokens; 6.951s. [Evidence](trials/03-priority_query-r1/evidence.json)
- 04-json_merge-r1: Docker 10/10 passed; workflow failed; failed agent node round-0/verify/inspect; 11 requests; 106,423 tokens; 45.997s. [Evidence](trials/04-json_merge-r1/evidence.json)
- 05-completion-r2: Docker 10/10 passed; workflow succeeded; failed agent node none; 8 requests; 27,747 tokens; 31.216s. [Evidence](trials/05-completion-r2/evidence.json)
- 06-bulk_edit-r2: Docker 10/10 passed; workflow failed; failed agent node round-0/verify/inspect; 10 requests; 72,752 tokens; 43.420s. [Evidence](trials/06-bulk_edit-r2/evidence.json)
- 07-priority_query-r2: Docker execution not observed; workflow failed; failed agent node develop; 6 requests; 32,498 tokens; 24.919s. [Evidence](trials/07-priority_query-r2/evidence.json)
- 08-json_merge-r2: Docker 10/10 passed; workflow failed; failed agent node round-0/verify/inspect; 10 requests; 93,072 tokens; 41.857s. [Evidence](trials/08-json_merge-r2/evidence.json)

## Interpretation and limits

- A live generated candidate, successful candidate write, immutable preregistered acceptance hash and complete isolated ten-test result are linked by candidate hash and event order. No review/gate is required to establish this test fact.
- Requires a linked complete isolated ten-test failure from the live model candidate; excludes baseline controls, synthetic defects, partial tests, infrastructure failures and model JSON contract failures. No review/gate is required.
- Requires the complete current test/review/gate and verified candidate hash. Docker tests alone do not establish workflow success.
- For trials 01, 04, 06 and 08 this means no completed validation gate. Their Docker tests did execute and passed 10/10.
- Legacy helper field reports a current passing result attached to a complete gate. False does not mean no Docker execution. Consult independent_docker_tests.
- Means a completed reviewer verdict passed=false while the test passed. A reviewer JSON contract failure is a protocol failure, not a review-only code rejection.
- Automatic code-repair success requires ordered failure, feedback, a changed live fixer candidate and revalidation. Protocol recovery is distinct from code repair.
- All six failed trials record a model JSON contract error. The original unsuccessful model content, finish_reason and parse error position were not persisted, so syntax errors, schema mismatch and truncation cannot be distinguished retroactively.
- All eight preregistered trials retained; no successful-only retry or model request was made by this audit.

## Observer correction and reproducibility

The original observer encountered normal null node IDs and pending null step outputs. An audited wrapper allowed observation of the same submitted runs without resubmission. After the batch ended, the two null guards were made permanent. Reclassification now agrees with every original round and outcome value; this audit does not rewrite those exports.

The detailed [JSON audit](audit_report.json) includes source hashes, exact Docker stdout/stderr, candidate and acceptance hashes, failed agent events and per-trial metrics. Original frozen source and task ordering remain in [preregistration.json](preregistration.json). All eight trials remain in the denominator.
