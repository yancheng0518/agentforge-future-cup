"""Audited observation-only null-node guard for this preregistered batch.

The first POST had succeeded. Its workflow continues unchanged; this wrapper
only prevents non-node status events from crashing report classification.
It preserves the original preregistration, frozen sources and run IDs.
"""
from pathlib import Path
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
import evaluate_tasks as observer

original = observer.valid_live_candidate


def valid_live_candidate(event, steps):
    if not isinstance(event.get("node_id"), str):
        return False
    return original(event, steps)


observer.valid_live_candidate = valid_live_candidate
original_classify = observer.classify_run


def classify_run(detail, task, provenance="live_developer_output_without_injection"):
    # A pending step has no output yet. Empty evidence remains unverified;
    # normalization is local to classification, never the raw run export.
    view = deepcopy(detail)
    for step in view.get("steps", []):
        if step.get("output") is None:
            step["output"] = {}
    return original_classify(view, task, provenance)


observer.classify_run = classify_run
directory = Path(__file__).resolve().parent
audit = directory / "observer-repair-audit.json"
if not audit.exists():
    audit.write_text(json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "reason": "Observer TypeError on legitimate status event node_id=None after first successful POST",
        "scope": "Observation/classification only; ignore non-node events as candidate-producing events",
        "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "original_preregistration_unchanged": True,
        "task_model_runtime_acceptance_unchanged": True,
        "resubmitted_runs": 0,
        "affected_run_id": "dc97b4e792fb4f598babc99e092ce346",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
revision = directory / "observer-repair-v2-audit.json"
if not revision.exists():
    revision.write_text(json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "reason": "Running steps legitimately have output=None; original classifier expected a dict",
        "scope": "Classify a copy treating null output as absent evidence; preserve original API export",
        "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "previous_wrapper": "observer_patch_v1.py.txt",
        "original_preregistration_unchanged": True,
        "task_model_runtime_acceptance_unchanged": True,
        "resubmitted_runs": 0,
        "affected_run_id": "03ff43f5ed5b4452b6752d7e5eacd4c5",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
sys.exit(observer.main(["--resume", str(directory)]))
