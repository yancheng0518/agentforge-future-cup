# AgentForge local reproduction archive

Paths preserve the workspace layout. Source and selected evidence bytes are copied unchanged. No model, candidate, installation or upload was performed by the exporter.

Start with README.md and docs/multi-task-evaluation.md. Recreate the Python environment from backend/requirements-lock.txt and frontend dependencies from frontend/package-lock.json. Configure a new local .env from .env.example and prepare Docker separately. Model reruns may incur usage and are not guaranteed to produce the same output. Never run candidate files on the host.

## Included evidence roots

- .agentforge/evaluations/20261108T084840Z-9d855f
- .agentforge/evaluations/20261108T090616Z-606cb8
- .agentforge/seeded-workflows/20261108T091215Z-1da7d89a
- .agentforge/task-controls/20261108T084610Z-fd7236
- .agentforge/protocol-probes/20261108T090302Z-98490fc0
- .agentforge/protocol-probes/20261108T090324Z-c09c8149

Evidence JSON, frozen source and candidate files are historical observations, not executable setup instructions. Natural failures, model contract failures and declared synthetic defects must remain separate. The selected JSON exports contain the audit records; SQLite databases and their WAL/SHM/journals are excluded to avoid distributing an inconsistent live database.

Excluded by default: .env credentials, unselected .agentforge data, WSL/disks/installers, node_modules, dist/build, virtual environments, caches, databases, archives and unsupported binary files. No browser screenshots or original slide deck are selected by default. Configured credential values are checked as exact bytes in UTF-8/UTF-16. This does not claim discovery of every unknown or encoded secret. Matching files cause refusal, not redaction.

REPRODUCTION_MANIFEST.json lists SHA-256 and size for every other ZIP member, including this README; the manifest cannot include its own hash. The exporter rereads every member and prints the final ZIP and manifest SHA-256. Hashes detect changes, not authorship.

Verify without extracting or executing content:

```powershell
python scripts/export_reproduction.py --verify path/to/archive.zip
```
