"""Read-only experimental evidence audit; writes only its own audit.json.

No project imports, model requests, subprocesses, Docker commands, candidate
imports or code execution. Run again with --require-complete after all trials.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    raw = path.read_bytes()
    return json.loads(raw), sha(raw)


def inside(batch, relative):
    path = batch / relative
    if Path(relative).is_absolute() or ".." in Path(relative).parts or not path.resolve().is_relative_to(batch):
        raise ValueError("Evidence path escapes batch")
    current = batch
    for component in Path(relative).parts:
        current = current / component
        if current.is_symlink():
            raise ValueError("Evidence symlink rejected")
    return path


def fingerprint(files):
    values = [{"path": f["path"], "after": f["after"]} for f in files]
    return sha(json.dumps(values, ensure_ascii=False, sort_keys=True).encode())


def timestamp(value):
    return datetime.fromisoformat(value)


def safe_error_summary(value):
    """Keep engine's error field, never provider bodies or request headers."""
    text = str(value or "")
    text = re.sub(r"(?i)\bBearer\s+\S+", "Bearer [REDACTED]", text)
    text = re.sub(r"(?i)\b(?:api[_-]?key|authorization|token|secret)\s*[:=]\s*\S+", "[REDACTED]", text)
    text = re.sub(r"\bsk-[A-Za-z0-9_-]+", "[REDACTED]", text)
    return text[:400]


def all_scoped_tests(value):
    result = []
    if isinstance(value, dict):
        if isinstance(value.get("evidence_scope"), dict) and "status" in value and "stdout" in value:
            result.append(value)
        for item in value.values():
            result.extend(all_scoped_tests(item))
    elif isinstance(value, list):
        for item in value:
            result.extend(all_scoped_tests(item))
    return result


def complete_suite(result, task):
    passed = result.get("status") == "passed"
    marker = "AGENTFORGE_ACCEPTANCE=" + json.dumps({"tests": 10, "passed": passed})
    return (result.get("status") in {"passed", "failed"} and result.get("isolated") is True
            and type(result.get("exit_code")) is int and result["exit_code"] == (0 if passed else 1)
            and marker in result.get("stdout", "")
            and re.search(r"Ran 10 tests? in ", result.get("stderr", "")) is not None
            and result.get("task_id") == task["id"] and result.get("acceptance_sha256") == task["acceptance_sha256"])


def coarse_functional_result(run, task):
    """Derive candidate->write->complete-suite independently of report code."""
    events = run["events"]
    scoped = all_scoped_tests(run)
    observations = []
    for candidate in events:
        node = candidate.get("node_id") or ""
        data = candidate.get("data") or {}
        output = data.get("output") or {}
        files = output.get("files") or []
        match = re.fullmatch(r"round-([12])/fix", node)
        if candidate.get("type") != "agent" or (node != "develop" and not match):
            continue
        if data.get("model_mode") != "live" or data.get("status") == "failed" or len(files) != 1 or output.get("preset_fault") is True:
            continue
        if files[0].get("path") != "todo.py" or not isinstance(files[0].get("content"), str):
            continue
        number = 0 if node == "develop" else int(match[1])
        candidate_hash = fingerprint([{"path": "todo.py", "after": files[0]["content"]}])
        writes = [e for e in events if e["id"] > candidate["id"] and e.get("node_id") == node
                  and e.get("type") == "tool" and e.get("data", {}).get("tool") == "candidate_diff"
                  and e["data"].get("status") == "completed" and e["data"].get("source") == "runtime"
                  and fingerprint((e["data"].get("output") or {}).get("files", [])) == candidate_hash]
        if not writes:
            continue
        scope = {"id": f"round-{number}/verify", "attempt": number, "candidate_hash": candidate_hash}
        for event in events:
            if event["id"] <= writes[-1]["id"] or event.get("node_id") != scope["id"] + "/test":
                continue
            tool = event.get("data") or {}
            if event.get("type") != "tool" or tool.get("source") != "runtime" or tool.get("tool") != "run_acceptance":
                continue
            result = tool.get("output") or {}
            linked = any(s.get("evidence_scope") == scope and {k: v for k, v in s.items() if k != "evidence_scope"} == result for s in scoped)
            if linked and complete_suite(result, task):
                observations.append({"round": number, "candidate_event_id": candidate["id"], "write_event_id": writes[-1]["id"],
                                     "test_event_id": event["id"], "candidate_hash": candidate_hash,
                                     "test_status": result["status"], "complete_tests": 10})
    final_hash = fingerprint((run.get("diff") or {}).get("files", []))
    final = [x for x in observations if x["round"] == run.get("attempt") and x["candidate_hash"] == final_hash]
    return {"final_candidate_hash": final_hash,
            "primary_success": bool(final and final[-1]["test_status"] == "passed"),
            "natural_test_failure_observed": any(x["test_status"] == "failed" for x in observations),
            "observations": observations}


def audit_trial(batch, plan, trial, batch_state=None):
    errors = []
    def check(condition, label):
        if not condition:
            errors.append(label)

    path = inside(batch, trial["evidence_path"])
    evidence, evidence_sha = read_json(path)
    run, ledger = evidence["run"], evidence["budget_ledger"]
    task = plan["task_catalog"][trial["task_id"]]
    arm = trial["arm"]
    check(run["id"] == trial["run_id"], "run_id")
    check(run["comparison_arm"] == arm and run["task_id"] == trial["task_id"], "task_arm")
    check(run["model_config"] == plan["model_config"], "frozen_model_config")
    check(run["agent_versions"] == plan["arms"][arm]["agent_versions"], "frozen_agents")
    check(run["workflow"] == plan["arms"][arm]["workflow"], "frozen_workflow")
    check(run["requirement"] == task["requirement"], "task_requirement")
    check(run["candidate_origin"] == "live_model_development" and run["fault_injection"] is False and run["applied"] is False, "candidate_origin")
    for key in ("id", "snapshot_sha256", "baseline_sha256", "requirement_sha256", "acceptance_sha256"):
        check(run["task"][key] == task[key] == run["task_snapshot"][key], "task_snapshot_" + key)
    for key in ("baseline", "requirement", "acceptance"):
        check(sha(run["task_snapshot"][key].encode()) == task[key + "_sha256"], "task_content_" + key)
    requests, denials = ledger["requests"], ledger["denials"]
    invocation_rows = ledger["invocations"]
    agent_events = [e for e in run["events"] if e["type"] == "agent"]
    http_errors = []
    for event in agent_events:
        data = event["data"]
        original = str(data.get("error") or "")
        match = re.search(r"\bHTTP\s+(\d{3})\b", original, re.IGNORECASE)
        if match:
            http_errors.append({"event_id": event["id"], "node_id": event["node_id"],
                                "invocation_id": data.get("invocation_id"),
                                "request_ids": data.get("request_ids", []), "http_status": int(match[1]),
                                "source_field": "agent.data.error", "error_summary": safe_error_summary(original),
                                "error_field_sha256": sha(original.encode()),
                                "metrics_complete": data.get("metrics_complete"),
                                "classification": "http_service_failure", "specific_cause": "not_established"})
    check([r["sequence"] for r in requests] == list(range(1, len(requests) + 1)), "request_sequence")
    request_ids = [r["request_id"] for r in requests]
    check(len(set(request_ids)) == len(request_ids), "request_ids_unique")
    check(len(requests) <= plan["limits"]["http_requests_per_trial"], "run_request_cap")
    check(ledger["max_requests"] == plan["limits"]["http_requests_per_trial"], "ledger_request_cap")
    check(ledger["sent_requests"] == len(requests) and ledger["denied_requests"] == len(denials), "ledger_totals")
    check(all(d["sent"] is False for d in denials), "denials_not_sent")
    check(ledger.get("audit_complete") is True and not ledger.get("unpersisted_artifacts"), "archive_complete")
    artifacts = []
    for request in requests:
        rid = request["request_id"]
        raw = inside(batch, request["artifact_path"]).read_bytes()
        check(sha(raw) == request["artifact_sha256"], "artifact_sha_" + rid)
        artifact = json.loads(raw)
        payload = artifact["payload"]
        body = json.dumps(payload).encode()
        check(sha(body) == request["payload_sha256"], "wire_sha_" + rid)
        check(len(body) == request["payload_bytes"] <= plan["limits"]["utf8_payload_bytes_per_request"], "wire_bytes_" + rid)
        check(payload["model"] == request["model"] == plan["model_config"]["model"], "model_" + rid)
        check(payload["temperature"] == request["temperature"] == plan["model_config"]["temperature"], "temperature_" + rid)
        check(payload["max_tokens"] == request["max_tokens"] == plan["limits"]["output_tokens_per_request"], "output_cap_" + rid)
        check(payload.get("response_format") == {"type": "json_object"}, "json_mode_" + rid)
        check(payload.get("thinking") == {"type": "disabled"}, "thinking_mode_" + rid)
        check(request["sent"] is True and request["status"] in {"completed", "failed"}, "terminal_request_" + rid)
        check(artifact.get("authorization_retained") is False and artifact.get("reasoning_retained") is False, "artifact_sensitive_flags_" + rid)
        for key in ("request_id", "invocation_id", "node_id", "node_kind", "agent_id", "status", "usage", "metrics_complete"):
            check(artifact["request"].get(key) == request.get(key), "artifact_metadata_" + key + "_" + rid)
        data = json.loads(payload["messages"][1]["content"])
        context, kind = data["context"], data["task"]["kind"]
        check(kind == request["node_kind"], "node_kind_" + rid)
        check(data["task"]["requirement"] == task["requirement"], "request_requirement_" + rid)
        check(context["task_contract"]["snapshot_sha256"] == task["snapshot_sha256"], "request_snapshot_" + rid)
        if kind == "inspect":
            check("test" not in context and "review" not in context, "inspect_input_mask_" + rid)
        if kind == "test":
            check("inspect" not in context and "review" not in context, "tester_input_mask_" + rid)
        if arm == "single_direct":
            check(kind in {"develop", "fix"} and request["agent_id"] == "single_direct", "single_agent_role_" + rid)
        if request["status"] == "completed":
            response = artifact.get("response") or {}
            for key, value in request["usage"].items():
                check((response.get("usage") or {}).get(key) == value, "response_usage_" + key + "_" + rid)
            for choice in response.get("choices", []):
                check("reasoning_content" not in (choice.get("message") or {}), "response_reasoning_excluded_" + rid)
        artifacts.append({"request_id": rid, "sha256": request["artifact_sha256"], "payload_bytes": len(body)})
    sent_tokens = sum(r.get("usage", {}).get("total_tokens", 0) for r in requests)
    sent_complete = all(r["status"] == "completed" and r["metrics_complete"] is True for r in requests)
    covered = []
    for event in agent_events:
        data = event["data"]
        matched = [r for r in requests if r["invocation_id"] == data.get("invocation_id")]
        invocations = [i for i in invocation_rows if i["invocation_id"] == data.get("invocation_id")]
        check(len(invocations) == 1, "invocation_link_" + str(event["id"]))
        expected = {"request_ids": [r["request_id"] for r in matched], "model_calls": len(matched),
                    "tokens": sum(r.get("usage", {}).get("total_tokens", 0) for r in matched),
                    "metrics_complete": all(r["status"] == "completed" and r["metrics_complete"] for r in matched)}
        for key, value in expected.items():
            check(data.get(key) == value, "agent_accounting_" + key + "_" + str(event["id"]))
            if invocations:
                check(invocations[0].get(key) == value, "invocation_accounting_" + key + "_" + str(event["id"]))
        check(len(matched) <= plan["limits"]["requests_per_agent_invocation"], "invocation_cap_" + str(event["id"]))
        check(data.get("contract_retries", 0) <= plan["limits"]["format_retries_per_invocation"], "format_retry_cap_" + str(event["id"]))
        check(all(r["node_id"] == event["node_id"] and r["agent_id"] == data["agent_id"] for r in matched), "request_agent_node_link_" + str(event["id"]))
        covered.extend(data.get("request_ids", []))
    check(Counter(covered) == Counter(request_ids), "every_request_accounted_once")
    check(len(invocation_rows) == len(agent_events) == run["agent_invocations"], "invocation_event_count")
    check(run["model_calls"] == sum(e["data"]["model_calls"] for e in agent_events) == len(requests), "three_layer_request_conservation")
    check(run["model_tokens"] == sum(e["data"]["tokens"] for e in agent_events) == sent_tokens == ledger["model_tokens_known"], "three_layer_token_conservation")
    check(run["model_metrics_complete"] == all(e["data"]["metrics_complete"] for e in agent_events) == sent_complete == ledger["metrics_complete"], "three_layer_usage_completeness")
    steps = {s["id"]: s for s in run["steps"]}
    timing = []
    for number in range(3):
        prefix = f"round-{number}/verify/"
        inspect, test, review = [steps.get(prefix + kind) for kind in ("inspect", "test", "review")]
        overlap = None
        if inspect and test and all(s.get("started_at") and s.get("finished_at") for s in (inspect, test)):
            overlap = max(0, (min(timestamp(inspect["finished_at"]), timestamp(test["finished_at"]))
                              - max(timestamp(inspect["started_at"]), timestamp(test["started_at"]))).total_seconds())
        if arm == "fixed_serial" and test:
            check(bool(inspect and inspect.get("finished_at") and timestamp(inspect["finished_at"]) <= timestamp(test["started_at"])), "serial_inspect_before_test_" + str(number))
        if arm != "single_direct" and review:
            check(all(s and s.get("finished_at") and timestamp(s["finished_at"]) <= timestamp(review["started_at"]) for s in (inspect, test)), "review_after_both_" + str(number))
        if inspect or test or review:
            timing.append({"round": number, "test_inspect_overlap_seconds": overlap,
                           "intervals": {kind: {k: s.get(k) for k in ("started_at", "finished_at", "status")} for kind, s in (("inspect", inspect), ("test", test), ("review", review)) if s}})
    if arm == "single_direct":
        check(len(run["agent_versions"]) == 1 and run["independent_review"] is False, "single_agent_definition")
        check(all(e["data"]["agent_id"] == "single_direct" for e in agent_events), "single_agent_events")
        check(not any(s["id"].endswith(("/inspect", "/review")) or s["id"] == "plan" for s in run["steps"]), "single_has_no_extra_model_stages")
    elif arm == "fixed_serial":
        expected_map = {"plan": "planner", "develop": "developer", "test": "tester", "inspect": "reviewer", "review": "reviewer", "fix": "fixer"}
        check(all(e["data"]["agent_id"] == expected_map[e["node_id"].split("/")[-1]] for e in agent_events), "fixed_mapping_actual")
    functional = coarse_functional_result(run, task)
    check(functional["primary_success"] == evidence["report"]["primary_success"], "independent_primary_endpoint_agrees")
    check(functional["natural_test_failure_observed"] == evidence["report"]["natural_test_failure_observed"], "independent_natural_failure_agrees")
    retries = sum(e["data"].get("contract_retries", 0) for e in agent_events)
    check(retries == evidence["report"]["contract_retries"], "format_retries_separate")
    blocked_tools = [{"event_id": event["id"], "node_id": event.get("node_id"),
                      "tool": event["data"].get("tool"), "status": event["data"].get("status"),
                      "error_summary": safe_error_summary(event["data"].get("error"))}
                     for event in run["events"] if event.get("type") == "tool"
                     and event.get("data", {}).get("status") in {"blocked", "interrupted"}]
    execution_interrupted = run.get("status") in {"blocked", "interrupted"} and bool(blocked_tools)
    batch_error = str((batch_state or {}).get("error") or "")
    local_recording_failure = (execution_interrupted and "[WinError 5]" in batch_error
                               and "state.json.pending" in batch_error and "state.json" in batch_error)
    lifecycle = {"record_state": trial["state"], "native_status": run.get("status"),
                 "execution_interrupted": execution_interrupted,
                 "classification": "local_recording_failure" if local_recording_failure else
                     "execution_interrupted" if execution_interrupted else "execution_finished",
                 "blocked_tool_events": blocked_tools,
                 "complete_test_suite_observed": bool(functional["observations"]),
                 "model_failure_observed": bool(http_errors or any(e["data"].get("status") == "failed" for e in agent_events)),
                 "candidate_test_failure_observed": functional["natural_test_failure_observed"]}
    if local_recording_failure:
        lifecycle["attribution_basis"] = {"type": "inference_from_batch_and_trial_evidence",
                                           "batch_source_field": "state.error",
                                           "batch_error_summary": safe_error_summary(batch_error),
                                           "batch_error_sha256": sha(batch_error.encode()),
                                           "note": "Batch state records a local state-file replace failure; this trial's acceptance tool was interrupted. No complete acceptance result is inferred."}
    return {"trial": trial["trial"], "task_id": trial["task_id"], "arm": arm, "run_id": run["id"], "verified": not errors,
            "evidence_sha256": evidence_sha, "errors": errors, "requests": len(requests), "tokens_known": sent_tokens,
            "model_metrics_complete": sent_complete,
            "contract_retries": retries, "http_errors": http_errors, "request_artifacts": artifacts,
            "timing": timing, "functional_endpoint": functional, "lifecycle": lifecycle,
            "snapshot_sha256": task["snapshot_sha256"], "sandbox_image": run["model_config"]["sandbox_image"]}


def combined_audit(batch, plan, state, child_output):
    """Independently verify a parent/child union without importing its merger."""
    reference = plan["continuation"]
    parent_name = reference["parent_batch"]
    if Path(parent_name).name != parent_name:
        raise ValueError("Parent must be an adjacent batch directory")
    parent = inside(batch.parent, parent_name)
    previous, previous_sha = read_json(parent / "preregistration.json")
    parent_state, parent_state_sha = read_json(parent / "state.json")
    errors = []
    def check(condition, label):
        if not condition:
            errors.append(label)

    check(previous_sha == reference["parent_preregistration_sha256"] == parent_state["preregistration_sha256"], "parent_preregistration_hash")
    check(parent_state_sha == reference["parent_state_sha256"], "parent_state_hash")
    check(parent_state["status"] in {"blocked", "interrupted"}, "parent_stopped")
    for relative, entry in previous["source_manifest"].items():
        check(sha(inside(parent, "frozen/" + relative).read_bytes()) == entry["sha256"], "parent_frozen_sha:" + relative)
    for key in ("schema", "task_order", "task_catalog", "arms", "repetitions", "model_config", "model_settings",
                "docker_image_id", "limits", "candidate_origin", "fault_injection", "budget_semantics", "ordering",
                "primary_endpoint", "secondary_endpoint", "controls"):
        check(plan.get(key) == previous.get(key), "same_condition:" + key)
    changes = {key: {"before": previous["source_manifest"].get(key), "after": plan["source_manifest"].get(key)}
               for key in sorted(previous["source_manifest"].keys() | plan["source_manifest"].keys())
               if previous["source_manifest"].get(key) != plan["source_manifest"].get(key)}
    expected_changes = {"scripts/evaluate_comparison.py", "scripts/evaluate_tasks.py",
                        "scripts/comparison_continuation.py", "scripts/merge_comparison.py"}
    check(set(changes) == expected_changes, "exactly_four_observer_source_differences")
    check(changes == reference["source_changes"], "source_differences_declared")
    controls, control_sha = read_json(parent / "controls/evidence.json")
    check(control_sha == previous["controls"]["source_sha256"] == child_output["controls_evidence_sha256"], "same_controls_archive")
    check(controls["docker_image_id"] == plan["docker_image_id"], "parent_controls_pinned_image")
    original = previous["trials"]
    identity = ("trial", "task_id", "arm", "repetition", "block", "arm_position")
    parent_rows = parent_state["trials"]
    check(len(parent_rows) == len(original) and all(all(a[k] == b[k] for k in identity) for a, b in zip(original, parent_rows)), "parent_inventory_identity_order")
    retained = [t for t in parent_rows if t.get("run_id") and t["state"] in {"complete", "interrupted"}]
    selected = [t for t in parent_rows if t["state"] == "not_submitted" and t.get("run_id") is None]
    check([t["trial"] for t in retained] == reference["retained_parent_trials"] == list(range(1, 16)), "retained_parent_1_to_15")
    check([t["trial"] for t in selected] == reference["selected_trial_ids"] == [t["trial"] for t in plan["trials"]] == list(range(16, 25)), "only_child_16_to_24")
    check(all(all(a[k] == b[k] for k in identity) for a, b in zip(selected, plan["trials"])), "child_slot_identity_order")
    claim, claim_sha = read_json(batch / "continuation-claim.json")
    check(claim_sha == state["continuation_claim"]["sha256"], "archived_claim_hash")
    check(claim["child_batch"] == batch.name and claim["child_preregistration_sha256"] == child_output["preregistration_sha256"], "claim_child_registration")
    check(all(claim["parent"].get(key) == reference[key] for key in ("parent_batch", "parent_preregistration_sha256", "parent_state_sha256", "retained_parent_trials", "selected_trial_ids")), "claim_parent_and_slots")
    starts = [t["started_at"] for t in state["trials"] if t.get("started_at")]
    check(not starts or timestamp(claim["created_at"]) <= min(timestamp(value) for value in starts), "claim_precedes_all_child_submissions")
    parent_results = []
    for row in retained:
        try:
            parent_results.append(audit_trial(parent, previous, row, parent_state))
        except Exception as exc:
            parent_results.append({"trial": row["trial"], "verified": False, "errors": ["audit_exception:" + type(exc).__name__]})
    prior_audit, prior_audit_sha = read_json(parent / "audits/audit.json")
    check(prior_audit.get("state_snapshot_sha256") == parent_state_sha and
          prior_audit.get("preregistration_sha256") == previous_sha, "parent_precontinuation_audit_binding")
    prior_evidence_hashes = {row["trial"]: row.get("evidence_sha256") for row in prior_audit["trials"]}
    check(all(row.get("evidence_sha256") == prior_evidence_hashes.get(row["trial"]) for row in parent_results), "parent_evidence_unchanged_since_prior_audit")
    results = [{**row, "phase": parent.name} for row in parent_results] + [{**row, "phase": batch.name} for row in child_output["trials"]]
    trials = [r["trial"] for r in results]
    check(len(trials) == len(set(trials)), "no_duplicate_trial_slots")
    run_ids = [r.get("run_id") for r in results if r.get("run_id")]
    check(len(run_ids) == len(set(run_ids)), "no_reused_run_ids")
    request_ids = [a["request_id"] for r in results for a in r.get("request_artifacts", [])]
    check(len(request_ids) == len(set(request_ids)), "no_reused_request_ids")
    check(child_output["checked_completed_trials_valid"], "child_audit_valid")
    check(all(row["verified"] for row in parent_results), "retained_parent_audit_valid")
    all_slots = sorted(trials) == [t["trial"] for t in original]
    merged_summary_check = {"observed": False}
    summary_path = batch / "combined-summary.json"
    if summary_path.exists():
        summary, summary_sha = read_json(summary_path)
        before_summary_errors = len(errors)
        check(summary["planned_trials"] == len(original) and summary["finished_trials"] == len(results), "merged_summary_grid_counts")
        check(summary.get("all_original_planned_slots_retained") is True and summary.get("all_trials_retained") is True,
              "merged_summary_all_slots_retained")
        check(summary.get("synthetic_trials_detected") == 0 and summary.get("synthetic_trials_included") is False,
              "merged_summary_synthetic_excluded")
        check(not summary.get("duplicate_observation_ids") and not summary.get("unexpected_trial_records"), "merged_summary_no_duplicates")
        by_arm = {}
        for arm in plan["arms"]:
            rows = [r for r in results if r.get("arm") == arm]
            counts = {"observed": len(rows), "finished": len(rows),
                      "primary_successes": sum(r.get("functional_endpoint", {}).get("primary_success", False) for r in rows),
                      "strategy_completed": sum(r.get("lifecycle", {}).get("native_status") == "succeeded" for r in rows),
                      "natural_test_failure_trials": sum(r.get("functional_endpoint", {}).get("natural_test_failure_observed", False) for r in rows),
                      "contract_retries": sum(r.get("contract_retries", 0) for r in rows),
                      "model_calls": sum(r.get("requests", 0) for r in rows),
                      "model_tokens_known": sum(r.get("tokens_known", 0) for r in rows),
                      "model_metrics_complete_for_observed": all(r.get("model_metrics_complete") is True for r in rows)}
            for key, value in counts.items():
                check(summary["by_arm"][arm].get(key) == value, "merged_summary_" + arm + "_" + key)
            by_arm[arm] = counts
        http_counts = dict(Counter(str(item["http_status"]) for r in results for item in r.get("http_errors", [])))
        check(http_counts == summary.get("http_status_failures"), "merged_summary_http_counts")
        summary_rows = {row["trial"]: row for row in summary["trials"]}
        check(len(summary_rows) == len(summary["trials"]) == len(results), "merged_summary_unique_trial_count")
        for row in results:
            matched = summary_rows.get(row["trial"], {})
            check(all(matched.get(key) == row.get(key) for key in ("run_id", "arm", "task_id", "phase")), "merged_summary_trial_identity:" + str(row["trial"]))
            check(matched.get("report", {}).get("primary_success") == row.get("functional_endpoint", {}).get("primary_success"),
                  "merged_summary_trial_primary:" + str(row["trial"]))
            check(matched.get("report", {}).get("native_status") == row.get("lifecycle", {}).get("native_status"),
                  "merged_summary_trial_native_status:" + str(row["trial"]))
        check(summary.get("stage_break", {}).get("present") is True and
              summary.get("stage_break", {}).get("affected_trial_ids") == [15], "merged_summary_keeps_infrastructure_interruption")
        merged_summary_check = {"observed": True, "sha256": summary_sha, "verified": len(errors) == before_summary_errors,
                                "independently_derived_by_arm": by_arm, "http_status_failures": http_counts}
    complete = all_slots and child_output["entire_batch_verified"] and not errors
    outcome = {"schema": "agentforge-independent-two-phase-audit-v1", "audited_at": datetime.now(timezone.utc).isoformat(),
               "mode": "final" if complete else "partial", "parent_batch": parent.name, "child_batch": batch.name,
               "original_planned_slots": len(original), "submitted_slots_audited": len(results),
               "remaining_slots_not_yet_audited": [t["trial"] for t in original if t["trial"] not in trials],
               "all_original_slots_accounted": all_slots, "checked_submitted_records_valid": not errors,
               "complete_grid_verified": complete, "single_uninterrupted_batch": False,
               "parent_original_status": parent_state["status"], "child_status": state["status"],
               "parent_preregistration_sha256": previous_sha, "parent_state_sha256": parent_state_sha,
               "parent_precontinuation_audit_sha256": prior_audit_sha,
               "child_preregistration_sha256": child_output["preregistration_sha256"], "child_state_snapshot_sha256": child_output["state_snapshot_sha256"],
               "auditor_sha256": sha(Path(__file__).read_bytes()), "source_changes": changes, "global_errors": errors,
               "merged_summary_comparison": merged_summary_check,
               "totals": {"primary_successes": sum(r.get("functional_endpoint", {}).get("primary_success", False) for r in results),
                          "natural_test_failure_trials": [r["trial"] for r in results if r.get("functional_endpoint", {}).get("natural_test_failure_observed")],
                          "format_retries": sum(r.get("contract_retries", 0) for r in results),
                          "http_failure_trial_ids": [r["trial"] for r in results if r.get("http_errors")],
                          "local_recording_failure_trial_ids": [r["trial"] for r in results if r.get("lifecycle", {}).get("classification") == "local_recording_failure"],
                          "requests": len(request_ids), "tokens_known": sum(r.get("tokens_known", 0) for r in results)},
               "trials": results,
               "boundary": "This is a union of two explicitly registered temporal phases, not an uninterrupted cohort. Parent trial 15 remains an interrupted primary-endpoint non-success; only parent never-submitted slots are supplied by the child. No model, Docker, candidate, frozen project module, or merger execution occurs in this auditor."}
    target = Path(__file__).parent / "combined-audit.json"
    temporary = target.with_suffix(".pending")
    temporary.write_text(json.dumps(outcome, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)
    print(json.dumps({"combined_mode": outcome["mode"], "submitted_slots_audited": len(results),
                      "complete_grid_verified": complete, "global_errors": errors}, ensure_ascii=False))
    return outcome


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    batch = Path(__file__).resolve().parents[1]
    plan, plan_sha = read_json(batch / "preregistration.json")
    state, state_sha = read_json(batch / "state.json")
    errors = []
    frozen_verified = 0
    for relative, entry in plan["source_manifest"].items():
        if sha(inside(batch, "frozen/" + relative).read_bytes()) != entry["sha256"]:
            errors.append("frozen_sha:" + relative)
        else:
            frozen_verified += 1
    if state.get("preregistration_sha256") != plan_sha:
        errors.append("preregistration_hash")
    if not (plan["docker_image_id"] == plan["controls"]["docker_image_id"] == plan["model_config"]["sandbox_image"]):
        errors.append("pinned_image_binding")
    controls, controls_sha = read_json(batch / "controls" / "evidence.json")
    if controls_sha != plan["controls"]["source_sha256"]:
        errors.append("controls_evidence_hash")
    if controls.get("docker_image_id") != plan["docker_image_id"] or controls.get("model_calls") != 0 or controls.get("passed") is not True:
        errors.append("controls_image_model_results")
    if plan["arms"]["fixed_serial"]["agent_versions"] != plan["arms"]["dynamic_parallel"]["agent_versions"]:
        errors.append("multi_agent_versions_differ")
    declared = {t["trial"]: t for t in plan["trials"]}
    observed_ids = [t["trial"] for t in state["trials"]]
    if Counter(observed_ids) != Counter(declared.keys()):
        errors.append("planned_trial_inventory")
    completed = [t for t in state["trials"] if t["state"] in {"complete", "interrupted"} and t.get("evidence_path")]
    not_submitted = [t for t in state["trials"] if t["state"] == "not_submitted"]
    for trial in not_submitted:
        if trial.get("run_id") is not None or trial.get("evidence_path"):
            errors.append("not_submitted_has_execution:" + str(trial["trial"]))
    results = []
    for trial in completed:
        if any(trial.get(k) != declared[trial["trial"]].get(k) for k in ("task_id", "arm", "repetition", "block", "arm_position")):
            errors.append("trial_plan_mismatch:" + str(trial["trial"]))
        try:
            results.append(audit_trial(batch, plan, trial, state))
        except Exception as exc:
            results.append({"trial": trial["trial"], "verified": False, "errors": ["audit_exception:" + type(exc).__name__]})
    finished_all = len(completed) == len(plan["trials"]) and state["status"] == "completed"
    checked_ok = not errors and all(r["verified"] for r in results)
    interrupted = [r["trial"] for r in results if r.get("lifecycle", {}).get("execution_interrupted")]
    local_recording = [r["trial"] for r in results if r.get("lifecycle", {}).get("classification") == "local_recording_failure"]
    batch_error = str(state.get("error") or "")
    output = {"schema": "agentforge-independent-comparison-audit-v1", "audited_at": datetime.now(timezone.utc).isoformat(),
              "mode": "final" if finished_all else "partial", "batch_id": plan["batch_id"], "planned_trials": len(plan["trials"]),
              "completed_trials_audited": len(completed), "unfinished_or_unsubmitted_trials": len(plan["trials"]) - len(completed),
              "completed_trials_count_semantics": "Exported terminal trial records, including interrupted/blocked native runs; not successful or uninterrupted executions.",
              "batch_status": state["status"], "batch_terminal": state["status"] in {"completed", "blocked", "interrupted", "failed"},
              "submitted_trial_records_audited": len(completed), "interrupted_trial_ids": interrupted,
              "local_recording_failure_trial_ids": local_recording,
              "not_submitted_trials": len(not_submitted), "not_submitted_trial_ids": [t["trial"] for t in not_submitted],
              "batch_failure": {"classification": "local_recording_failure" if local_recording else "other_failure" if batch_error else None,
                                "source_field": "state.error", "error_summary": safe_error_summary(batch_error),
                                "error_field_sha256": sha(batch_error.encode()) if batch_error else None},
              "checked_completed_trials_valid": checked_ok, "entire_batch_verified": finished_all and checked_ok,
              "preregistration_sha256": plan_sha, "state_snapshot_sha256": state_sha,
              "auditor_sha256": sha(Path(__file__).read_bytes()), "frozen_files_verified": frozen_verified,
              "controls_evidence_sha256": controls_sha,
              "global_errors": errors, "trials": results,
              "boundary": "Timing measures node lifetimes, not simultaneous HTTP. Image binding is verified from frozen code/config and controls, not per-container inspection. Terminal exported records may represent interrupted runs; no complete suite or model/candidate failure is inferred from interruption. Not-submitted slots remain distinct from submitted failures. No model, Docker, or candidate execution performed by this audit."}
    target = Path(__file__).parent / "audit.json"
    temporary = target.with_suffix(".pending")
    temporary.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(target)
    print(json.dumps({k: output[k] for k in ("mode", "planned_trials", "completed_trials_audited", "unfinished_or_unsubmitted_trials", "checked_completed_trials_valid", "entire_batch_verified", "global_errors")}, ensure_ascii=False))
    for result in results:
        if result["errors"]:
            print(json.dumps({"trial": result["trial"], "errors": result["errors"]}, ensure_ascii=False))
    combined = combined_audit(batch, plan, state, output) if plan.get("continuation") else None
    combined_ok = combined is None or (combined["checked_submitted_records_valid"] and
                                       (combined["complete_grid_verified"] or not args.require_complete))
    return 0 if checked_ok and combined_ok and (finished_all or not args.require_complete) else 2


if __name__ == "__main__":
    raise SystemExit(main())
