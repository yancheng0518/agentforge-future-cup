"""Todo store with atomic bulk editing support.

Implements the base completion behaviour plus rename, delete and atomic
batch completion. Only the standard library is used.
"""


def _validate_task_id(task_id):
    """Validate a single task id: must be a positive int, not a bool."""
    if type(task_id) is not int or task_id <= 0:
        raise ValueError("task id must be a positive integer")


def _validate_title(title):
    """Validate and normalise a title the same way add() does."""
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title must not be empty")
    return title.strip()


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def _find(self, task_id):
        for task in self._tasks:
            if task["id"] == task_id:
                return task
        return None

    def add(self, title):
        title = _validate_title(title)
        task = {"id": self._next_id, "title": title, "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def rename(self, task_id, title):
        _validate_task_id(task_id)
        title = _validate_title(title)
        task = self._find(task_id)
        if task is None:
            raise KeyError(task_id)
        task["title"] = title
        return dict(task)

    def delete(self, task_id):
        _validate_task_id(task_id)
        task = self._find(task_id)
        if task is None:
            raise KeyError(task_id)
        self._tasks.remove(task)
        return dict(task)

    def batch_complete(self, task_ids, completed=True):
        if type(completed) is not bool:
            raise ValueError("completed must be a bool")
        if type(task_ids) is not list:
            raise ValueError("task_ids must be a list")

        seen = set()
        for task_id in task_ids:
            _validate_task_id(task_id)
            if task_id in seen:
                raise ValueError("duplicate task id in batch")
            seen.add(task_id)

        # Validate existence of every id before mutating anything.
        targets = []
        for task_id in task_ids:
            task = self._find(task_id)
            if task is None:
                raise KeyError(task_id)
            targets.append(task)

        for task in targets:
            task["completed"] = completed

        return [dict(task) for task in targets]
