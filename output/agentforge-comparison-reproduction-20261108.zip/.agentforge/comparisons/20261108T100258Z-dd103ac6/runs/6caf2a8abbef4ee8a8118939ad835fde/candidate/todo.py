"""TodoStore with versioned JSON export/import merge."""

import json


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def add(self, title):
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must not be empty")
        task = {"id": self._next_id, "title": title.strip(), "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def export_json(self):
        tasks = [
            {"id": task["id"], "title": task["title"], "completed": task["completed"]}
            for task in self._tasks
        ]
        return json.dumps({"version": 1, "tasks": tasks})

    def import_json(self, payload, collision="error"):
        if not isinstance(collision, str) or collision not in ("error", "replace", "skip"):
            raise ValueError("invalid collision mode")

        if not isinstance(payload, str):
            raise ValueError("payload must be a string")
        try:
            document = json.loads(payload)
        except (ValueError, TypeError):
            raise ValueError("payload is not valid JSON")

        if not isinstance(document, dict):
            raise ValueError("top level must be an object")
        if set(document.keys()) != {"version", "tasks"}:
            raise ValueError("top level must contain exactly version and tasks")

        version = document["version"]
        if type(version) is not int or version != 1:
            raise ValueError("version must be integer 1")

        raw_tasks = document["tasks"]
        if not isinstance(raw_tasks, list):
            raise ValueError("tasks must be a list")

        normalized = []
        seen_ids = set()
        for item in raw_tasks:
            if not isinstance(item, dict):
                raise ValueError("each task must be an object")
            if set(item.keys()) != {"id", "title", "completed"}:
                raise ValueError("each task must contain exactly id, title, completed")

            task_id = item["id"]
            if type(task_id) is not int or task_id <= 0:
                raise ValueError("id must be a positive integer")

            title = item["title"]
            if not isinstance(title, str):
                raise ValueError("title must be a string")
            stripped = title.strip()
            if not stripped:
                raise ValueError("title must not be empty")

            completed = item["completed"]
            if type(completed) is not bool:
                raise ValueError("completed must be a boolean")

            if task_id in seen_ids:
                raise ValueError("duplicate id in input")
            seen_ids.add(task_id)

            normalized.append({"id": task_id, "title": stripped, "completed": completed})

        existing = {task["id"]: task for task in self._tasks}

        if collision == "error":
            for task in normalized:
                if task["id"] in existing:
                    raise ValueError("id already exists")

        inserted = 0
        updated = 0
        skipped = 0
        new_tasks = []

        for task in normalized:
            if task["id"] in existing:
                if collision == "replace":
                    existing[task["id"]]["title"] = task["title"]
                    existing[task["id"]]["completed"] = task["completed"]
                    updated += 1
                else:
                    skipped += 1
            else:
                new_tasks.append({
                    "id": task["id"],
                    "title": task["title"],
                    "completed": task["completed"],
                })
                inserted += 1

        self._tasks.extend(new_tasks)

        if self._tasks:
            max_id = max(task["id"] for task in self._tasks)
            if max_id + 1 > self._next_id:
                self._next_id = max_id + 1

        return {"inserted": inserted, "updated": updated, "skipped": skipped}
