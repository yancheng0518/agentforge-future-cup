"""TodoStore with completion, priority, and stable paginated queries."""


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def add(self, title):
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must not be empty")
        task = {
            "id": self._next_id,
            "title": title.strip(),
            "completed": False,
            "priority": 1,
        }
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def set_priority(self, task_id, priority):
        if type(task_id) is not int or task_id <= 0:
            raise ValueError("task_id must be a positive integer")
        if type(priority) is not int or priority not in (0, 1, 2, 3):
            raise ValueError("priority must be an integer in 0..3")
        for task in self._tasks:
            if task["id"] == task_id:
                task["priority"] = priority
                return dict(task)
        raise KeyError(task_id)

    def query(self, completed=None, min_priority=0, limit=None, offset=0):
        if completed is not None and type(completed) is not bool:
            raise ValueError("completed must be None, True, or False")
        if type(min_priority) is not int or min_priority not in (0, 1, 2, 3):
            raise ValueError("min_priority must be an integer in 0..3")
        if type(offset) is not int or offset < 0:
            raise ValueError("offset must be a non-negative integer")
        if limit is not None and (type(limit) is not int or limit < 0):
            raise ValueError("limit must be None or a non-negative integer")

        filtered = [
            task for task in self._tasks
            if (completed is None or task["completed"] is completed)
            and task["priority"] >= min_priority
        ]
        filtered.sort(key=lambda task: (-task["priority"], task["id"]))

        if limit is None:
            page = filtered[offset:]
        else:
            page = filtered[offset:offset + limit]
        return [dict(task) for task in page]
