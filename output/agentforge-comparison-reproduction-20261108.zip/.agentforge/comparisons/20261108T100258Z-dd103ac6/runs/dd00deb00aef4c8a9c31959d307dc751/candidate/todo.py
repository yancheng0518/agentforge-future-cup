"""TodoStore with completion plus rename, delete and atomic batch completion."""


def _validate_id(task_id):
    """Return True if task_id is a positive int (bool rejected)."""
    return type(task_id) is int and task_id > 0


def _validate_title(title):
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title must not be empty")
    return title.strip()


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def _find(self, task_id):
        for task in self._tasks:
            if task["id"] == task_id:
                return task
        return None

    def add(self, title):
        clean = _validate_title(title)
        task = {"id": self._next_id, "title": clean, "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def rename(self, task_id, title):
        if not _validate_id(task_id):
            raise ValueError("task_id must be a positive int")
        clean = _validate_title(title)
        task = self._find(task_id)
        if task is None:
            raise KeyError(task_id)
        task["title"] = clean
        return dict(task)

    def delete(self, task_id):
        if not _validate_id(task_id):
            raise ValueError("task_id must be a positive int")
        task = self._find(task_id)
        if task is None:
            raise KeyError(task_id)
        self._tasks = [t for t in self._tasks if t["id"] != task_id]
        return dict(task)

    def batch_complete(self, task_ids, completed=True):
        if type(completed) is not bool:
            raise ValueError("completed must be a bool")
        if type(task_ids) is not list:
            raise ValueError("task_ids must be a list")
        seen = set()
        for task_id in task_ids:
            if not _validate_id(task_id):
                raise ValueError("each task_id must be a positive int")
            if task_id in seen:
                raise ValueError("duplicate task_id")
            seen.add(task_id)
        # Existence check for all ids before any mutation.
        for task_id in task_ids:
            if self._find(task_id) is None:
                raise KeyError(task_id)
        results = []
        for task_id in task_ids:
            task = self._find(task_id)
            task["completed"] = completed
            results.append(dict(task))
        return results
