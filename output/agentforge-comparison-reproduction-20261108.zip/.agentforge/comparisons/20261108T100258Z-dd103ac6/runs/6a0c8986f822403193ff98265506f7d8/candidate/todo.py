"""TodoStore with completion, priority and stable paginated queries."""

_PRIORITIES = (0, 1, 2, 3)


def _is_exact_int(value):
    return type(value) is int


def _validate_task_id(task_id):
    if not _is_exact_int(task_id) or task_id <= 0:
        raise ValueError("task_id must be a positive integer")


def _validate_priority(priority):
    if not _is_exact_int(priority) or priority not in _PRIORITIES:
        raise ValueError("priority must be an integer in 0..3")


def _validate_completed(completed):
    if completed is None:
        return
    if completed is True or completed is False:
        return
    raise ValueError("completed must be None, True or False")


def _validate_min_priority(min_priority):
    if not _is_exact_int(min_priority) or min_priority not in _PRIORITIES:
        raise ValueError("min_priority must be an integer in 0..3")


def _validate_offset(offset):
    if not _is_exact_int(offset) or offset < 0:
        raise ValueError("offset must be a non-negative integer")


def _validate_limit(limit):
    if limit is None:
        return
    if not _is_exact_int(limit) or limit < 0:
        raise ValueError("limit must be None or a non-negative integer")


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def add(self, title):
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must not be empty")
        task = {
            "id": self._next_id,
            "title": title.strip(),
            "completed": False,
            "priority": 1,
        }
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def set_priority(self, task_id, priority):
        _validate_task_id(task_id)
        _validate_priority(priority)
        for task in self._tasks:
            if task["id"] == task_id:
                task["priority"] = priority
                return dict(task)
        raise KeyError(task_id)

    def query(self, completed=None, min_priority=0, limit=None, offset=0):
        _validate_completed(completed)
        _validate_min_priority(min_priority)
        _validate_limit(limit)
        _validate_offset(offset)

        filtered = [
            task for task in self._tasks
            if (completed is None or task["completed"] is completed)
            and task["priority"] >= min_priority
        ]
        ordered = sorted(filtered, key=lambda task: (-task["priority"], task["id"]))
        page = ordered[offset:] if limit is None else ordered[offset:offset + limit]
        return [dict(task) for task in page]
