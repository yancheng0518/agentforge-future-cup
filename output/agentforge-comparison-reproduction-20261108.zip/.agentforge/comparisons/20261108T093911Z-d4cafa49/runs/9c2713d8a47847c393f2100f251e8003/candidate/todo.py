"""Todo store with completion, rename, delete and atomic batch completion."""


def _validate_id(task_id):
    """Validate a task id: must be a real int (not bool) and positive."""
    if type(task_id) is not int or task_id <= 0:
        raise ValueError("task id must be a positive integer")
    return task_id


def _validate_title(title):
    """Validate and normalize a title: non-empty string, stripped."""
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title must not be empty")
    return title.strip()


def _validate_completed(completed):
    """Validate the completed flag: must be exactly a bool."""
    if type(completed) is not bool:
        raise ValueError("completed must be a bool")
    return completed


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def _find(self, task_id):
        for task in self._tasks:
            if task["id"] == task_id:
                return task
        raise KeyError(task_id)

    def add(self, title):
        title = _validate_title(title)
        task = {"id": self._next_id, "title": title, "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        task = self._find(task_id)
        task["completed"] = bool(completed)
        return dict(task)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def rename(self, task_id, title):
        _validate_id(task_id)
        title = _validate_title(title)
        task = self._find(task_id)
        task["title"] = title
        return dict(task)

    def delete(self, task_id):
        _validate_id(task_id)
        task = self._find(task_id)
        self._tasks.remove(task)
        return dict(task)

    def batch_complete(self, task_ids, completed=True):
        if type(task_ids) is not list:
            raise ValueError("task_ids must be a list")
        _validate_completed(completed)
        seen = set()
        for task_id in task_ids:
            _validate_id(task_id)
            if task_id in seen:
                raise ValueError("duplicate task id in batch")
            seen.add(task_id)
        # Existence check for the whole batch before any mutation.
        targets = [self._find(task_id) for task_id in task_ids]
        for task in targets:
            task["completed"] = completed
        return [dict(task) for task in targets]
