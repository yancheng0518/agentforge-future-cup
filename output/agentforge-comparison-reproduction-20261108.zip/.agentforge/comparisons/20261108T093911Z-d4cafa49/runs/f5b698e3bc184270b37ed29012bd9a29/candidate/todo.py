"""TodoStore with completion, priority, and stable paginated queries."""

_PRIORITIES = (0, 1, 2, 3)


def _is_int(value):
    return type(value) is int


def _validate_priority(priority):
    if not _is_int(priority) or priority not in _PRIORITIES:
        raise ValueError("priority must be an integer in 0..3")


def _validate_task_id(task_id):
    if not _is_int(task_id) or task_id <= 0:
        raise ValueError("task_id must be a positive integer")


def _validate_completed(completed):
    if completed is None or completed is True or completed is False:
        return
    raise ValueError("completed must be None, True, or False")


def _validate_non_negative_int(value, name):
    if not _is_int(value) or value < 0:
        raise ValueError("%s must be a non-negative integer" % name)


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def add(self, title):
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must not be empty")
        task = {
            "id": self._next_id,
            "title": title.strip(),
            "completed": False,
            "priority": 1,
        }
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def set_priority(self, task_id, priority):
        _validate_task_id(task_id)
        _validate_priority(priority)
        for task in self._tasks:
            if task["id"] == task_id:
                task["priority"] = priority
                return dict(task)
        raise KeyError(task_id)

    def query(self, completed=None, min_priority=0, limit=None, offset=0):
        _validate_completed(completed)
        _validate_priority(min_priority)
        _validate_non_negative_int(offset, "offset")
        if limit is not None:
            _validate_non_negative_int(limit, "limit")

        filtered = [
            task for task in self._tasks
            if (completed is None or task["completed"] is completed)
            and task["priority"] >= min_priority
        ]
        ordered = sorted(filtered, key=lambda task: (-task["priority"], task["id"]))

        if limit is None:
            page = ordered[offset:]
        else:
            page = ordered[offset:offset + limit]
        return [dict(task) for task in page]
