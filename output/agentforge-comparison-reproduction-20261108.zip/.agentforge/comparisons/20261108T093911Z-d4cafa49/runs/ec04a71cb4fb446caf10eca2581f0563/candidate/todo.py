"""Todo store with atomic bulk editing support.

Baseline completion behaviour is preserved; rename, delete and atomic
batch_complete are implemented on top of it.
"""


def _validate_title(title):
    if not isinstance(title, str) or not title.strip():
        raise ValueError("title must not be empty")
    return title.strip()


def _validate_task_id(task_id):
    if type(task_id) is not int or task_id <= 0:
        raise ValueError("task id must be a positive integer")
    return task_id


def _validate_completed(completed):
    if type(completed) is not bool:
        raise ValueError("completed must be a bool")
    return completed


class TodoStore:
    def __init__(self):
        self._tasks = []
        self._next_id = 1

    def _find(self, task_id):
        for task in self._tasks:
            if task["id"] == task_id:
                return task
        return None

    def add(self, title):
        clean = _validate_title(title)
        task = {"id": self._next_id, "title": clean, "completed": False}
        self._next_id += 1
        self._tasks.append(task)
        return dict(task)

    def complete(self, task_id, completed=True):
        for task in self._tasks:
            if task["id"] == task_id:
                task["completed"] = bool(completed)
                return dict(task)
        raise KeyError(task_id)

    def list(self, completed=None):
        return [dict(task) for task in self._tasks
                if completed is None or task["completed"] == completed]

    def rename(self, task_id, title):
        _validate_task_id(task_id)
        clean = _validate_title(title)
        task = self._find(task_id)
        if task is None:
            raise KeyError(task_id)
        task["title"] = clean
        return dict(task)

    def delete(self, task_id):
        _validate_task_id(task_id)
        for index, task in enumerate(self._tasks):
            if task["id"] == task_id:
                removed = self._tasks.pop(index)
                return dict(removed)
        raise KeyError(task_id)

    def batch_complete(self, task_ids, completed=True):
        if type(task_ids) is not list:
            raise ValueError("task_ids must be a list")
        _validate_completed(completed)
        seen = set()
        for task_id in task_ids:
            _validate_task_id(task_id)
            if task_id in seen:
                raise ValueError("duplicate task id in batch")
            seen.add(task_id)
        targets = []
        for task_id in task_ids:
            task = self._find(task_id)
            if task is None:
                raise KeyError(task_id)
            targets.append(task)
        for task in targets:
            task["completed"] = completed
        return [dict(task) for task in targets]
