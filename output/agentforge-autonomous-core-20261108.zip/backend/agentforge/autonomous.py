"""Version 1 model-directed orchestration, independent of the legacy task catalogue.

The controller decides the graph and its revisions. This executor only enforces
dependencies, file ownership, budgets and an independent evidence-based finish gate.
"""
from __future__ import annotations

import asyncio
from copy import deepcopy
import hashlib
import json
import re
import time
from uuid import uuid4

from .autonomous_model import AutonomousModel, ModelBudgetExceeded
from .autonomous_sandbox import AutonomousSandbox, SandboxIntegrityError
from .runtime import RuntimeErrorSafe
from .storage import now


DEFAULT_BUDGET = dict(max_calls=40, max_tokens=200000, max_output_tokens=4096,
                      max_steps=24, max_tasks=32, max_parallel=3,
                      max_verifications=8, wall_seconds=900)
LIMITS = dict(max_calls=(1, 100), max_tokens=(4096, 1000000),
              max_output_tokens=(512, 8192), max_steps=(1, 60),
              max_tasks=(1, 64), max_parallel=(1, 4),
              max_verifications=(1, 20), wall_seconds=(30, 3600))


def budget_config(value=None):
    value = value or {}
    if not isinstance(value, dict) or set(value) - set(DEFAULT_BUDGET):
        raise ValueError("Unknown budget setting")
    result = {**DEFAULT_BUDGET, **value}
    for key, (low, high) in LIMITS.items():
        if type(result[key]) is not int or not low <= result[key] <= high:
            raise ValueError(f"{key} must be an integer between {low} and {high}")
    return result


class DecisionRejected(ValueError):
    """Recoverable controller decision, recorded separately from format retries."""


def safe_path(path):
    if (not isinstance(path, str) or len(path) > 180 or
            not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_/]*\.py", path) or
            any(x in ("", ".", "..") for x in path.split("/"))):
        raise DecisionRejected("write_paths must be relative Python source paths")
    return path


class AutonomousEngine:
    revision = "model-directed-v1"

    def __init__(self, store, runtime, model=None, sandbox=None):
        self.store, self.runtime = store, runtime
        self.model = model or AutonomousModel(runtime, store)
        self.sandbox = sandbox or AutonomousSandbox(runtime)
        self.tasks = {}
        self.running = set()

    def create_run(self, bundle, budget=None):
        frozen = self.sandbox.validate_bundle(bundle)
        limits = budget_config(budget)
        run = dict(id=uuid4().hex, engine=self.revision, mode="live", status="queued",
                   requirement=frozen["requirement"], bundle=deepcopy(frozen), budget=limits,
                   created_at=now(), updated_at=now(), applied=False,
                   summary="等待主 Agent 分解任务", model_config=(self.model.config(limits)
                   if hasattr(self.model, "config") else self.runtime.model_config()),
                   controller_decisions=[], task_graph=[], verifications=[],
                   feedback=None, candidate_origin="baseline", verified_hash=None,
                   model_metrics=dict(model_calls=0, tokens=0, metrics_complete=True,
                                      contract_retries=0, in_flight=0, reserved_tokens=0))
        run["bundle_sha256"] = hashlib.sha256(json.dumps(frozen, ensure_ascii=False,
                                                         sort_keys=True).encode()).hexdigest()
        self.store.create_run(run)
        self.store.event(run["id"], "created", "建立独立的动态编排运行", data={
            "engine": self.revision, "bundle_sha256": run["bundle_sha256"],
            "provenance": frozen["provenance"], "budget": limits})
        return run

    def start(self, run_id):
        if run_id not in self.tasks or self.tasks[run_id].done():
            self.tasks[run_id] = asyncio.create_task(self.execute(run_id))
        return self.tasks[run_id]

    def _save(self, run_id, **fields):
        return self.store.update_run(run_id, **fields)

    def recover_interrupted(self):
        """A process restart cannot establish remote completion; never replay it."""
        with self.store.connect() as db:
            runs = [json.loads(row[0]) for row in db.execute("SELECT body FROM runs")]
        for run in runs:
            if run.get("engine") != self.revision or run["status"] not in ("queued", "running"):
                continue
            graph = deepcopy(run["task_graph"])
            for task in graph:
                if task["status"] == "running":
                    task.update(status="failed", error="Process interrupted; completion unconfirmed", finished_at=now())
                    self.store.step(run["id"], task)
            metrics = deepcopy(run["model_metrics"])
            previous = deepcopy(metrics)
            if metrics.get("in_flight", 0):
                metrics["budget_tokens"] = metrics.get("budget_tokens", 0) + metrics.get("reserved_tokens", 0)
                metrics["unknown_usage_calls"] = metrics.get("unknown_usage_calls", 0) + metrics["in_flight"]
                metrics.update(in_flight=0, reserved_tokens=0, metrics_complete=False)
            self._save(run["id"], status="blocked", task_graph=graph, model_metrics=metrics,
                       summary="进程中断，未确认远端请求是否完成；证据已保留，不自动重放。需新建运行。")
            self.store.event(run["id"], "interrupted_recovery", "恢复运行记录，未重新发送请求",
                             data={"metrics_before": previous, "metrics_after": metrics})

    async def _context(self, run_id):
        run = self.store.run(run_id)
        return dict(requirement=run["requirement"], project=await self.sandbox.read(run_id),
                    tasks=run["task_graph"], last_verification=(run["verifications"][-1]
                    if run["verifications"] else None), feedback=run.get("feedback"),
                    decisions=run["controller_decisions"][-6:], budget=run["budget"],
                    usage=run["model_metrics"], provenance=run["bundle"]["provenance"],
                    candidate_hash=await self.sandbox.fingerprint(run_id))

    def _dispatch(self, run, decision):
        graph = deepcopy(run["task_graph"])
        additions = decision.get("tasks")
        if not isinstance(additions, list) or not additions:
            raise DecisionRejected("dispatch requires nonempty tasks")
        if len(graph) + len(additions) > run["budget"]["max_tasks"]:
            raise DecisionRejected("Total task budget exceeded")
        known = {t["id"] for t in graph}
        for task in additions:
            if not isinstance(task, dict) or set(task) != {"id", "title", "instructions", "depends_on", "write_paths"}:
                raise DecisionRejected("Task fields must be id,title,instructions,depends_on,write_paths")
            identity = task["id"]
            if not isinstance(identity, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", identity) or identity in known:
                raise DecisionRejected("Task IDs must be unique, bounded and cannot be reused")
            if any(not isinstance(task[k], str) or not task[k].strip() or len(task[k]) > cap
                   for k, cap in (("title", 200), ("instructions", 12000))):
                raise DecisionRejected("Task title/instructions missing or too long")
            for key in ("depends_on", "write_paths"):
                if not isinstance(task[key], list) or any(not isinstance(x, str) for x in task[key]) or len(set(task[key])) != len(task[key]):
                    raise DecisionRejected(f"{key} must contain unique strings")
            for path in task["write_paths"]:
                safe_path(path)
            known.add(identity)
            graph.append({**deepcopy(task), "status": "pending", "agent_id": "worker-" + uuid4().hex[:12]})
        by_id = {t["id"]: t for t in graph}
        new_ids = {t["id"] for t in additions}
        visiting, visited = set(), set()

        def visit(identity):
            if identity in visiting:
                raise DecisionRejected("Dependency cycle")
            if identity in visited:
                return
            visiting.add(identity)
            for dependency in by_id[identity]["depends_on"]:
                if dependency not in by_id:
                    raise DecisionRejected("Unknown dependency: " + dependency)
                if identity in new_ids and by_id[dependency]["status"] in ("failed", "cancelled"):
                    raise DecisionRejected("Cannot depend on a failed or cancelled task")
                visit(dependency)
            visiting.remove(identity)
            visited.add(identity)

        for identity in by_id:
            visit(identity)
        self._save(run["id"], task_graph=graph)
        self.store.event(run["id"], "plan_revision", "主 Agent 增加实际执行任务",
                         data={"added": additions, "summary": decision["summary"]})

    async def _wave(self, run_id):
        run = self.store.run(run_id)
        graph = deepcopy(run["task_graph"])
        successful = {t["id"] for t in graph if t["status"] == "succeeded"}
        chosen, owned = [], set()
        for task in graph:
            if task["status"] != "pending" or not set(task["depends_on"]) <= successful:
                continue
            if {path.casefold() for path in task["write_paths"]} & owned:
                continue
            chosen.append(task)
            owned.update(path.casefold() for path in task["write_paths"])
            if len(chosen) == run["budget"]["max_parallel"]:
                break
        if not chosen:
            raise DecisionRejected("No ready tasks: cancel/replace failed dependencies or dispatch new tasks")
        context = await self._context(run_id)
        for task in chosen:
            task.update(status="running", started_at=now())
            self.store.step(run_id, task)
        self._save(run_id, task_graph=graph)
        self.store.event(run_id, "dispatch", "向本次任务创建的子 Agent 分配就绪任务",
                         data={"tasks": [{"id": t["id"], "agent_id": t["agent_id"],
                                          "write_paths": t["write_paths"]} for t in chosen]})
        # Workers see the same frozen candidate. Only disjoint write sets share a wave.
        results = await asyncio.gather(*(self.model.work(run, deepcopy(task), deepcopy(context))
                                         for task in chosen), return_exceptions=True)
        summaries = []
        for task, result in zip(chosen, results):
            try:
                if isinstance(result, BaseException):
                    raise result
                patch = await self.sandbox.apply(run_id, result["files"], task["write_paths"])
                task.update(status="succeeded", result={"summary": result["summary"],
                            "changed_paths": sorted(result["files"]), "patch": patch})
                if result["files"]:
                    self._save(run_id, candidate_origin="model", verified_hash=None)
            except asyncio.CancelledError:
                raise
            except SandboxIntegrityError as exc:
                task.update(status="failed", error=str(exc), finished_at=now(), integrity_failure=True)
                self.store.step(run_id, task)
                self._save(run_id, task_graph=graph)
                self.store.event(run_id, "integrity_failure", "候选完整性未获确认，停止运行", task["id"], task)
                raise
            except Exception as exc:
                # Safe transport exceptions never contain HTTP credentials/bodies.
                message = str(exc) if isinstance(exc, (RuntimeErrorSafe, ValueError)) else type(exc).__name__
                task.update(status="failed", error=message)
            task["finished_at"] = now()
            self.store.step(run_id, task)
            self._save(run_id, task_graph=graph)
            self.store.event(run_id, "task_result", "子 Agent 结果已保存", task["id"], deepcopy(task))
            summaries.append({"id": task["id"], "status": task["status"],
                              "result": task.get("result"), "error": task.get("error")})
        self._save(run_id, task_graph=graph, feedback={"kind": "execution_results", "results": summaries})
        self.store.snapshot(run_id, "wave", {"task_graph": graph,
                            "candidate_hash": await self.sandbox.fingerprint(run_id)})

    async def _verify(self, run_id):
        run = self.store.run(run_id)
        if len(run["verifications"]) >= run["budget"]["max_verifications"]:
            raise ModelBudgetExceeded("Independent verification budget exhausted")
        before = await self.sandbox.fingerprint(run_id)
        result = await self.sandbox.test(run_id)
        after = await self.sandbox.fingerprint(run_id)
        if before != after:
            raise RuntimeErrorSafe("Candidate changed during independent verification")
        baseline = run["candidate_origin"] == "baseline"
        seeded = run["bundle"]["provenance"]["kind"] == "seeded_defect"
        classification = ("seeded_defect_baseline" if seeded else "input_baseline") if baseline else (
            "seeded_experiment_candidate" if seeded else "natural_candidate")
        result = {**result, "candidate_hash": before, "candidate_origin": run["candidate_origin"],
                  "classification": classification, "index": len(run["verifications"]) + 1,
                  "timestamp": now()}
        verifications = run["verifications"] + [result]
        passed = (result["status"] == "passed" and result["isolated"] is True
                  and result["exit_code"] == 0 and result.get("test_count", 0) > 0)
        self._save(run_id, verifications=verifications, verified_hash=before if passed else None,
                   feedback={"kind": "verification", "result": result})
        self.store.event(run_id, "verification", "独立 Docker 验收已记录", data=result)
        if result["status"] == "blocked":
            raise RuntimeErrorSafe("Docker verification blocked; no host fallback")

    async def _action(self, run_id, decision):
        run = self.store.run(run_id)
        action = decision["action"]
        if action == "dispatch":
            self._dispatch(run, decision)
            await self._wave(run_id)
        elif action == "continue":
            await self._wave(run_id)
        elif action == "cancel":
            ids = decision.get("task_ids", [])
            graph = deepcopy(run["task_graph"])
            eligible = {t["id"] for t in graph if t["status"] == "pending"}
            if not ids or not set(ids) <= eligible:
                raise DecisionRejected("Only existing pending tasks can be cancelled")
            for task in graph:
                if task["id"] in ids:
                    task.update(status="cancelled", finished_at=now())
                    self.store.step(run_id, task)
            self._save(run_id, task_graph=graph, feedback={"kind": "cancelled", "task_ids": ids})
            self.store.event(run_id, "plan_revision", "主 Agent 撤销待执行任务", data=decision)
        elif action == "verify":
            await self._verify(run_id)
        elif action == "finish":
            if any(t["status"] in ("pending", "running") for t in run["task_graph"]):
                raise DecisionRejected("Pending tasks must be completed or explicitly cancelled before finishing")
            fingerprint = await self.sandbox.fingerprint(run_id)
            if not run["verified_hash"] or fingerprint != run["verified_hash"]:
                raise DecisionRejected("Finish requires current candidate to pass independent Docker verification")
            self._save(run_id, status="succeeded", summary=decision["summary"])
        elif action == "stop":
            self._save(run_id, status="needs_human", summary=decision["summary"])
        else:
            raise DecisionRejected("Unknown controller action")

    async def _loop(self, run_id):
        run = self.store.run(run_id)
        await self.sandbox.prepare(run_id, run["bundle"])
        for index in range(run["budget"]["max_steps"]):
            current = self.store.run(run_id)
            decision = await self.model.decide(current, await self._context(run_id))
            record = {"index": index + 1, "timestamp": now(), **decision}
            self._save(run_id, controller_decisions=current["controller_decisions"] + [record])
            self.store.event(run_id, "controller_decision", "主 Agent 决策", data=record)
            try:
                await self._action(run_id, decision)
            except DecisionRejected as exc:
                feedback = {"kind": "decision_rejected", "reason": str(exc), "decision": record}
                self._save(run_id, feedback=feedback)
                self.store.event(run_id, "decision_rejected", str(exc), data=feedback)
            if self.store.run(run_id)["status"] != "running":
                return
        raise ModelBudgetExceeded("Controller decision budget exhausted")

    async def execute(self, run_id):
        run = self.store.run(run_id)
        if not run or run.get("engine") != self.revision:
            raise ValueError("Not an autonomous run")
        if run_id in self.running or run["status"] != "queued":
            return
        self.running.add(run_id)
        started = time.monotonic()
        self._save(run_id, status="running", summary="主 Agent 正在编排")
        try:
            configuration = (self.model.config(run["budget"]) if hasattr(self.model, "config")
                             else self.runtime.model_config())
            if configuration != run["model_config"]:
                raise RuntimeErrorSafe("Frozen model configuration changed")
            async with asyncio.timeout(run["budget"]["wall_seconds"]):
                await self._loop(run_id)
        except (ModelBudgetExceeded, TimeoutError) as exc:
            self._save(run_id, status="needs_human", summary=str(exc) or "Run wall-time budget exhausted")
        except asyncio.CancelledError:
            self._save(run_id, status="blocked", summary="运行被中断；保留证据，不自动重放模型调用")
            raise
        except Exception as exc:
            summary = str(exc) if isinstance(exc, (RuntimeErrorSafe, ValueError)) else type(exc).__name__
            self._save(run_id, status="failed", summary=summary)
        finally:
            self.running.discard(run_id)
            final_run = self.store.run(run_id)
            interrupted = deepcopy(final_run["task_graph"])
            for task in interrupted:
                if task["status"] == "running":
                    task.update(status="failed", error="Execution interrupted; completion unconfirmed", finished_at=now())
                    self.store.step(run_id, task)
                    self.store.event(run_id, "task_interrupted", "子任务未获完成确认", task["id"], task)
            self._save(run_id, task_graph=interrupted)
            self._save(run_id, duration_seconds=round(time.monotonic() - started, 3))
            self.store.event(run_id, "terminal", "动态编排运行结束", data={
                "status": self.store.run(run_id)["status"], "summary": self.store.run(run_id)["summary"]})

    def export(self, run_id):
        return {"run": self.store.run(run_id), "events": self.store.events(run_id),
                "steps": self.store.steps(run_id), "snapshots": self.store.snapshots(run_id, include_context=True)}
