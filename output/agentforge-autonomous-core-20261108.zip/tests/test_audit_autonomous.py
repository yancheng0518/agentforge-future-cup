"""Synthetic evidence-only audit tests; never execute candidates or call services."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sqlite3

import pytest

SPEC = importlib.util.spec_from_file_location("audit_autonomous", Path(__file__).resolve().parents[1] / "scripts/audit_autonomous.py")
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


def write_db(data, runs, events=None):
    data.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(data / "agentforge.sqlite3") as db:
        db.executescript("CREATE TABLE runs(id TEXT,body TEXT); CREATE TABLE events(run_id TEXT,body TEXT); CREATE TABLE steps(run_id TEXT,body TEXT); CREATE TABLE snapshots(run_id TEXT,body TEXT);")
        for run in runs:
            db.execute("INSERT INTO runs VALUES(?,?)", (run["id"], json.dumps(run)))
        for event in events or []:
            db.execute("INSERT INTO events VALUES(?,?)", (runs[0]["id"], json.dumps(event)))


def base_run(identifier="fixture-1"):
    bundle = {"requirement": "Synthetic audit evidence only", "files": {"x.py": "# never executed\n"},
              "acceptance": "# synthetic fixture, not a real test suite\n", "provenance": {"kind": "natural"}}
    return {"id": identifier, "engine": "model-directed-v1", "mode": "live", "status": "blocked",
            "bundle": bundle, "bundle_sha256": AUDIT.digest(json.dumps(bundle, ensure_ascii=False, sort_keys=True)),
            "controller_decisions": [], "task_graph": [], "verifications": [],
            "model_metrics": {"model_calls": 0, "tokens": 0, "metrics_complete": True}, "verified_hash": None,
            "model_config": {"model": "fake-evidence-only"}, "budget": {"max_calls": 10}}


def complete_fixture(data):
    run = base_run()
    run["status"] = "succeeded"
    base = data / "runs" / run["id"]
    bundle = run["bundle"]
    write_json(base / "bundle.json", bundle)
    (base / "candidate").mkdir(parents=True)
    (base / "candidate/x.py").write_text(bundle["files"]["x.py"], encoding="utf-8")
    (base / "trusted").mkdir()
    (base / "trusted/test_acceptance.py").write_text(bundle["acceptance"], encoding="utf-8")
    (base / "runner").mkdir()
    (base / "runner/runner.py").write_text("# synthetic runner\n", encoding="utf-8")
    manifest = {"bundle_sha256": AUDIT.digest(AUDIT.canonical(bundle)),
                "acceptance_sha256": AUDIT.digest(bundle["acceptance"]),
                "baseline_sha256": AUDIT.digest(AUDIT.canonical(bundle["files"])),
                "runner_sha256": {"runner.py": AUDIT.digest("# synthetic runner\n")}}
    write_json(base / "autonomous_manifest.json", manifest)
    fingerprint = AUDIT.digest(AUDIT.canonical(bundle["files"]))
    run["verified_hash"] = fingerprint
    snapshot = "evidence/1-validation-start.json"
    write_json(base / snapshot, {"files": bundle["files"], "candidate_sha256": fingerprint})
    result = {"status": "passed", "isolated": True, "exit_code": 0, "test_count": 1,
              "candidate_sha256": fingerprint, "acceptance_sha256": manifest["acceptance_sha256"],
              "runner_sha256": manifest["runner_sha256"], "snapshot": snapshot,
              "result_record": "evidence/2-validation-result-synthetic.json",
              "container_invoked": True, "image": "sha256:" + "1" * 64,
              "attestation": {"tests": 1, "discovered": 1, "passed": True, "nonce": "synthetic"}}
    write_json(base / result["result_record"], result)
    run["verifications"] = [{**result, "candidate_hash": fingerprint, "candidate_origin": "baseline", "classification": "input_baseline", "index": 1}]
    events = []
    for index, action in enumerate(("verify", "finish"), 1):
        output = {"action": action, "summary": "Synthetic evidence, not a real model output"}
        record = {"run_id": run["id"], "sequence": index, "role": "main", "task_id": None,
                  "status": "accepted", "format_retry": False, "usage_known": True,
                  "usage": {"total_tokens": 20}, "budget_charge_tokens": 20, "reserved_budget_tokens": 100,
                  "content": json.dumps(output), "output": output}
        write_json(base / "model_requests" / f"{index:04d}.json", record)
        decision = {"index": index, "timestamp": "synthetic", **output}
        run["controller_decisions"].append(decision)
        events.extend([{"type": "model_request", "data": {"sequence": index}},
                       {"type": "controller_decision", "data": decision}])
    events.append({"type": "verification", "data": run["verifications"][0]})
    run["model_metrics"] = {"model_calls": 2, "tokens": 40, "budget_tokens": 40, "metrics_complete": True,
                            "unknown_usage_calls": 0, "contract_retries": 0, "in_flight": 0, "reserved_tokens": 0}
    write_db(data, [run], events)
    return run, base


def test_complete_synthetic_evidence_passes_without_mutating_inputs(tmp_path):
    data = tmp_path / "input"
    complete_fixture(data)
    before = {p.relative_to(data).as_posix(): p.read_bytes() for p in data.rglob("*") if p.is_file()}
    result = AUDIT.audit(data)
    after = {p.relative_to(data).as_posix(): p.read_bytes() for p in data.rglob("*") if p.is_file()}
    assert result["passed"], result["issues"]
    assert result["aggregate"]["runs"] == 1 and result["aggregate"]["model_calls"] == 2
    assert result["aggregate"]["known_tokens"] == 40
    assert result["aggregate"]["natural_candidate_failures"] == 0
    assert before == after


def test_audit_reads_more_than_100_runs_including_unexecuted_failures(tmp_path):
    data = tmp_path / "input"
    write_db(data, [base_run(f"record-{index}") for index in range(107)])
    result = AUDIT.audit(data)
    assert result["passed"], result["issues"]
    assert result["aggregate"]["runs"] == len(result["runs"]) == 107
    assert result["aggregate"]["non_successful_runs"] == 107


@pytest.mark.parametrize("tamper", ["tokens", "candidate", "acceptance", "runner", "decision", "request"])
def test_audit_detects_independent_evidence_corruption(tmp_path, tamper):
    data = tmp_path / "input"
    run, base = complete_fixture(data)
    if tamper in {"tokens", "decision"}:
        if tamper == "tokens":
            run["model_metrics"]["tokens"] += 1
        else:
            run["controller_decisions"][0]["summary"] = "Rewritten decision"
        with sqlite3.connect(data / "agentforge.sqlite3") as db:
            db.execute("UPDATE runs SET body=?", (json.dumps(run),))
    elif tamper == "request":
        (base / "model_requests/0001.json").unlink()
    else:
        path = {"candidate": "candidate/x.py", "acceptance": "trusted/test_acceptance.py", "runner": "runner/runner.py"}[tamper]
        (base / path).write_text("# rewritten\n", encoding="utf-8")
    result = AUDIT.audit(data)
    assert not result["passed"]
    assert any(i["severity"] == "error" for i in result["issues"])


def test_unknown_transport_failure_and_format_retry_stay_separate(tmp_path):
    data = tmp_path / "input"
    run, base = complete_fixture(data)
    failed = {"run_id": run["id"], "sequence": 3, "role": "worker", "task_id": "never-completed",
              "status": "transport_failed", "format_retry": True, "usage_known": False,
              "budget_charge_tokens": 100, "reserved_budget_tokens": 100, "error": "Synthetic HTTP 429"}
    write_json(base / "model_requests/0003.json", failed)
    run["model_metrics"].update(model_calls=3, budget_tokens=140, unknown_usage_calls=1, metrics_complete=False, contract_retries=1)
    with sqlite3.connect(data / "agentforge.sqlite3") as db:
        db.execute("UPDATE runs SET body=?", (json.dumps(run),))
        db.execute("INSERT INTO events VALUES(?,?)", (run["id"], json.dumps({"type": "model_request", "data": {"sequence": 3}})))
    result = AUDIT.audit(data)
    assert result["passed"], result["issues"]
    counts = result["aggregate"]
    assert counts["model_calls"] == 3 and counts["known_tokens"] == 40
    assert counts["unknown_usage_calls"] == counts["format_retries"] == counts["transport_failed_requests"] == 1
    assert counts["natural_candidate_failures"] == counts["seeded_candidate_failures"] == 0


def test_leaky_evidence_is_flagged_and_audit_report_redacts_secret(tmp_path):
    data = tmp_path / "input"
    run = base_run()
    secret = "synthetic-secret-never-valid"
    run["bundle"]["provenance"]["note"] = secret
    run["bundle_sha256"] = AUDIT.digest(json.dumps(run["bundle"], ensure_ascii=False, sort_keys=True))
    write_db(data, [run])
    result = AUDIT.audit(data, secret=secret)
    assert not result["passed"]
    assert not result["secret_scan"]["passed"]
    assert secret not in json.dumps(result)
    assert result["runs"][0]["provenance"]["note"] == "[REDACTED]"


def test_existing_output_is_never_overwritten(tmp_path):
    output = tmp_path / "existing.json"
    output.write_text("preserve me", encoding="utf-8")
    with pytest.raises(SystemExit) as exc:
        AUDIT.main(["--data-dir", str(tmp_path / "input"), "--output", str(output)])
    assert exc.value.code == 2
    assert output.read_text(encoding="utf-8") == "preserve me"


def test_output_cannot_be_written_inside_read_only_input_tree(tmp_path):
    with pytest.raises(SystemExit) as exc:
        AUDIT.main(["--data-dir", str(tmp_path), "--output", str(tmp_path / "audit.json")])
    assert exc.value.code == 2
    assert not (tmp_path / "audit.json").exists()
