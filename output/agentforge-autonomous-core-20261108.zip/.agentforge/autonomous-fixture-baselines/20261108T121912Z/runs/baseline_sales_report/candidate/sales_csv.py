"""Sales CSV parsing; prices are integer cents."""

def parse_sales(text):
    raise NotImplementedError("Implement the requested CSV contract")
