"""Aggregations and public report entry point."""

def summarize(rows):
    raise NotImplementedError("Implement aggregation")

def report(text, min_total_cents=0):
    raise NotImplementedError("Implement the composed report")
