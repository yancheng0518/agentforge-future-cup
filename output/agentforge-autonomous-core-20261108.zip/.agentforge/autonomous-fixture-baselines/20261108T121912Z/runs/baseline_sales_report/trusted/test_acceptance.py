import unittest
from bridge import call


class SalesAcceptance(unittest.TestCase):
    def test_parse_preserves_order_and_cents(self):
        self.assertEqual(call("sales_csv", "parse_sales", "region,amount\nEast,0.10\nWest,12.34\nEast,0.20\n"), [
            {"region": "East", "amount_cents": 10}, {"region": "West", "amount_cents": 1234},
            {"region": "East", "amount_cents": 20}])

    def test_csv_quoting_whitespace_blank_rows(self):
        self.assertEqual(call("sales_csv", "parse_sales", 'region,amount\n" North, East ", 2.50 \n\nSouth,0.00\n'), [
            {"region": "North, East", "amount_cents": 250}, {"region": "South", "amount_cents": 0}])

    def test_header_only(self):
        self.assertEqual(call("sales_csv", "parse_sales", "region,amount\n"), [])

    def test_reject_invalid_csv(self):
        for text in ("", "amount,region\n1.00,A", "region,amount\nA,1.001", "region,amount\nA,-1.00", "region,amount\nA,1e2", "region,amount\n,2.00", "region,amount\nA,2.00,extra"):
            with self.subTest(text=text), self.assertRaises(ValueError):
                call("sales_csv", "parse_sales", text)

    def test_aggregate_sorted_repeated_regions(self):
        rows = [{"region": "West", "amount_cents": 300}, {"region": "East", "amount_cents": 100}, {"region": "West", "amount_cents": 20}]
        self.assertEqual(call("sales_report", "summarize", rows), [
            {"region": "East", "total_cents": 100, "count": 1}, {"region": "West", "total_cents": 320, "count": 2}])

    def test_aggregate_zero_and_empty(self):
        self.assertEqual(call("sales_report", "summarize", []), [])
        self.assertEqual(call("sales_report", "summarize", [{"region": "Z", "amount_cents": 0}]), [{"region": "Z", "total_cents": 0, "count": 1}])

    def test_large_integer_money_stays_exact(self):
        self.assertEqual(call("sales_report", "report", "region,amount\nA,90071992547409.93\nA,0.01\n"), [{"region": "A", "total_cents": 9007199254740994, "count": 2}])

    def test_report_composes_modules(self):
        self.assertEqual(call("sales_report", "report", "region,amount\nB,1.20\nA,0.10\nB,2.30\nA,0.20\n"), [
            {"region": "A", "total_cents": 30, "count": 2}, {"region": "B", "total_cents": 350, "count": 2}])

    def test_report_inclusive_threshold(self):
        self.assertEqual(call("sales_report", "report", "region,amount\nA,1.00\nB,0.99\nC,2.00\n", min_total_cents=100), [
            {"region": "A", "total_cents": 100, "count": 1}, {"region": "C", "total_cents": 200, "count": 1}])

    def test_report_empty_after_filter(self):
        self.assertEqual(call("sales_report", "report", "region,amount\nA,1.00\n", min_total_cents=101), [])

    def test_invalid_threshold(self):
        for threshold in (-1, True, 1.2, "100"):
            with self.subTest(threshold=threshold), self.assertRaises(ValueError):
                call("sales_report", "report", "region,amount\nA,1.00\n", min_total_cents=threshold)

    def test_zero_threshold_keeps_zero(self):
        self.assertEqual(call("sales_report", "report", "region,amount\nZero,0.00\n"), [{"region": "Zero", "total_cents": 0, "count": 1}])
