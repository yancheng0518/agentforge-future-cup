import unittest
from bridge import call


class IntervalAcceptance(unittest.TestCase):
    def test_normalize_empty_and_zero_length(self):
        self.assertEqual(call("intervals", "normalize", []), [])
        self.assertEqual(call("intervals", "normalize", [[2, 2], [0, 0]]), [])

    def test_normalize_sort_merge_touch_overlap(self):
        self.assertEqual(call("intervals", "normalize", [[5, 8], [1, 3], [3, 5], [7, 10], [-3, -1]]), [[-3, -1], [1, 10]])

    def test_normalize_nested_duplicate_negative(self):
        self.assertEqual(call("intervals", "normalize", [[-8, -2], [-7, -3], [-8, -2], [4, 6]]), [[-8, -2], [4, 6]])

    def test_reject_invalid_intervals(self):
        for intervals in ([[3, 1]], [[False, 2]], [[1, 2.5]], [[1]], [[1, 2, 3]], ["ab"]):
            with self.subTest(intervals=intervals), self.assertRaises(ValueError):
                call("intervals", "normalize", intervals)

    def test_contains_half_open_boundaries(self):
        for point, expected in ((1, True), (4, True), (5, False), (0, False)):
            with self.subTest(point=point):
                self.assertIs(call("intervals", "contains", [[1, 5]], point), expected)

    def test_contains_unsorted_and_empty(self):
        self.assertIs(call("intervals", "contains", [[9, 12], [-3, 1]], -1), True)
        self.assertIs(call("intervals", "contains", [], 0), False)

    def test_contains_reject_invalid_point(self):
        for point in (True, 1.5, "2"):
            with self.subTest(point=point), self.assertRaises(ValueError):
                call("intervals", "contains", [[0, 5]], point)

    def test_gaps_clip_and_merge_coverage(self):
        self.assertEqual(call("intervals", "gaps", [[-4, 2], [4, 6], [6, 8], [9, 15]], 0, 10), [[2, 4], [8, 9]])

    def test_gaps_empty_and_full_window(self):
        self.assertEqual(call("intervals", "gaps", [], -2, 3), [[-2, 3]])
        self.assertEqual(call("intervals", "gaps", [[-4, 8]], -2, 3), [])

    def test_gaps_outside_and_empty_window(self):
        self.assertEqual(call("intervals", "gaps", [[-10, -5], [10, 20]], 0, 5), [[0, 5]])
        self.assertEqual(call("intervals", "gaps", [[1, 3]], 2, 2), [])

    def test_gaps_reject_invalid_window(self):
        for start, end in ((3, 2), (False, 2), (0, 2.5)):
            with self.subTest(start=start, end=end), self.assertRaises(ValueError):
                call("intervals", "gaps", [], start, end)

    def test_large_integers(self):
        low = 10 ** 20
        self.assertEqual(call("intervals", "gaps", [[low + 1, low + 2]], low, low + 3), [[low, low + 1], [low + 2, low + 3]])
