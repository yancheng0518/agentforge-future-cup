"""Half-open integer interval utilities."""

def normalize(intervals):
    raise NotImplementedError("Implement interval normalization")

def contains(intervals, point):
    raise NotImplementedError("Implement membership")

def gaps(intervals, start, end):
    raise NotImplementedError("Implement window gaps")
