import unittest
from bridge import call


class ShippingAcceptance(unittest.TestCase):
    def test_empty_order(self):
        self.assertEqual(call("shipping", "shipping_cost", [], 0), 0)
        self.assertEqual(call("shipping", "shipping_cost", [], 5000, express=True), 0)

    def test_under_and_exact_first_kilogram(self):
        self.assertEqual(call("shipping", "shipping_cost", [1], 0), 500)
        self.assertEqual(call("shipping", "shipping_cost", [400, 600], 4999), 500)

    def test_one_gram_over_first_kilogram(self):
        self.assertEqual(call("shipping", "shipping_cost", [1001], 0), 700)

    def test_partial_second_kilogram(self):
        self.assertEqual(call("shipping", "shipping_cost", [750, 750], 100), 700)

    def test_exact_additional_kilograms(self):
        self.assertEqual(call("shipping", "shipping_cost", [2000], 0), 700)
        self.assertEqual(call("shipping", "shipping_cost", [3000], 0), 900)

    def test_round_each_started_kilogram(self):
        self.assertEqual(call("shipping", "shipping_cost", [2001], 0), 900)
        self.assertEqual(call("shipping", "shipping_cost", [4200], 0), 1300)

    def test_free_threshold_is_inclusive(self):
        self.assertEqual(call("shipping", "shipping_cost", [3000], 4999), 900)
        self.assertEqual(call("shipping", "shipping_cost", [3000], 5000), 0)

    def test_express_surcharge(self):
        self.assertEqual(call("shipping", "shipping_cost", [1000], 0, express=True), 900)
        self.assertEqual(call("shipping", "shipping_cost", [3000], 5000, express=True), 400)

    def test_invalid_weights(self):
        for weights in ([0], [-1], [True], [1.5], "1000"):
            with self.subTest(weights=weights), self.assertRaises(ValueError):
                call("shipping", "shipping_cost", weights, 0)

    def test_invalid_other_arguments_even_empty(self):
        for subtotal in (-1, True, "5"):
            with self.subTest(subtotal=subtotal), self.assertRaises(ValueError):
                call("shipping", "shipping_cost", [], subtotal)
        with self.assertRaises(ValueError):
            call("shipping", "shipping_cost", [], 0, express="yes")
