import unittest
from bridge import call
class Tests(unittest.TestCase):
    def test_add(self):
        self.assertEqual(call("arithmetic", "add", 2, 3), 5)
