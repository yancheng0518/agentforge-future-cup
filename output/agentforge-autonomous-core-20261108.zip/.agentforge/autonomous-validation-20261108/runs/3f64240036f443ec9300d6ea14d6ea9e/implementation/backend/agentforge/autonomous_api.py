"""Separate API/data store for model-directed runs; legacy records stay untouched."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from .autonomous import AutonomousEngine
from .runtime import Runtime
from .storage import Store


class AutonomousRunInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    bundle: dict
    budget: dict = Field(default_factory=dict)


def mount_autonomous(app, root, data_dir):
    data_dir = data_dir / "autonomous"
    store = Store(data_dir / "agentforge.sqlite3")
    runtime = Runtime(root, data_dir)
    engine = AutonomousEngine(store, runtime)
    router = APIRouter(prefix="/api/autonomous")

    def require_run(run_id):
        run = store.run(run_id)
        if not run:
            raise HTTPException(404, "动态运行不存在")
        return run

    @router.post("/runs", status_code=201)
    async def create(body: AutonomousRunInput):
        if sum(not task.done() for task in engine.tasks.values()) >= 2:
            raise HTTPException(429, "最多并发 2 个动态运行")
        health = await runtime.health()
        if not health["model"]["configured"] or not health["sandbox"]["available"]:
            raise HTTPException(409, "动态运行需要真实模型配置和 Docker；不会切换模拟或主机执行")
        try:
            run = engine.create_run(body.bundle, body.budget)
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(422, str(exc)) from None
        engine.start(run["id"])
        return {k: v for k, v in run.items() if k != "bundle"}

    @router.get("/runs")
    async def list_runs():
        return [{k: v for k, v in run.items() if k != "bundle"} for run in store.runs()]

    @router.get("/runs/{run_id}")
    async def get_run(run_id: str):
        require_run(run_id)
        return engine.export(run_id)

    @router.get("/runs/{run_id}/candidate")
    async def candidate(run_id: str):
        require_run(run_id)
        return {"files": await engine.sandbox.read(run_id),
                "sha256": await engine.sandbox.fingerprint(run_id)}

    app.include_router(router)
    app.state.autonomous_engine = engine
    app.state.autonomous_store = store
    return engine
