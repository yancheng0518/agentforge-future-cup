"""Sales CSV parsing; prices are integer cents."""

import csv
import io
import re

_HEADER = ["region", "amount"]
_AMOUNT_RE = re.compile(r"\A[0-9]+\.[0-9]{2}\Z")


def _amount_to_cents(field):
    """Convert a validated decimal string to integer cents without float."""
    if not _AMOUNT_RE.match(field):
        raise ValueError("invalid amount: %r" % (field,))
    whole, fraction = field.split(".")
    return int(whole) * 100 + int(fraction)


def parse_sales(text):
    """Parse sales CSV text into rows of {"region": str, "amount_cents": int}."""
    if not isinstance(text, str):
        raise ValueError("sales CSV must be provided as text")
    if not text.strip():
        raise ValueError("empty sales CSV")

    try:
        reader = csv.reader(io.StringIO(text, newline=""))
        raw_rows = list(reader)
    except csv.Error as exc:
        raise ValueError("malformed CSV: %s" % (exc,)) from exc

    if not raw_rows:
        raise ValueError("missing header row")

    header = [field.strip() for field in raw_rows[0]]
    if header != _HEADER:
        raise ValueError("unexpected header: %r" % (header,))

    rows = []
    for raw_row in raw_rows[1:]:
        fields = [field.strip() for field in raw_row]
        if not any(fields):
            continue
        if len(fields) != 2:
            raise ValueError(
                "expected exactly 2 columns, got %d: %r" % (len(fields), fields)
            )
        region, amount = fields
        if not region:
            raise ValueError("missing region")
        rows.append({"region": region, "amount_cents": _amount_to_cents(amount)})

    return rows
