'''Aggregations and public report entry point.'''

import sales_csv


def summarize(rows):
    '''Group rows by region and return lexicographically sorted totals.'''
    grouped = {}
    for row in rows:
        region = row['region']
        amount_cents = row['amount_cents']
        if region not in grouped:
            grouped[region] = [0, 0]
        grouped[region][0] += amount_cents
        grouped[region][1] += 1

    return [
        {
            'region': region,
            'total_cents': grouped[region][0],
            'count': grouped[region][1],
        }
        for region in sorted(grouped)
    ]


def report(text, min_total_cents=0):
    '''Parse sales text and return groups meeting the minimum total.'''
    if isinstance(min_total_cents, bool) or not isinstance(min_total_cents, int):
        raise ValueError('min_total_cents must be a non-negative integer')
    if min_total_cents < 0:
        raise ValueError('min_total_cents must be a non-negative integer')

    groups = summarize(sales_csv.parse_sales(text))
    return [
        group for group in groups
        if group['total_cents'] >= min_total_cents
    ]
