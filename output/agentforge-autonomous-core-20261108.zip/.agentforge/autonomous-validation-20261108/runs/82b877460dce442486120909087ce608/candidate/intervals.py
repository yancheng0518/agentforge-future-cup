"""Half-open integer interval utilities."""


def _check_int(value, name):
    """Return value if it is a non-bool integer, otherwise raise ValueError."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("%s must be an integer" % name)
    return value


def _validated(intervals):
    """Validate intervals and return non-empty (start, end) tuples."""
    if not isinstance(intervals, list):
        raise ValueError("intervals must be a list")

    cleaned = []
    for interval in intervals:
        if type(interval) is not list or len(interval) != 2:
            raise ValueError("each interval must be a two-element list")

        start = _check_int(interval[0], "interval start")
        end = _check_int(interval[1], "interval end")
        if end < start:
            raise ValueError("interval end must be greater than or equal to start")

        if start != end:
            cleaned.append((start, end))

    return cleaned


def normalize(intervals):
    """Return sorted, disjoint, non-empty intervals covering the input."""
    cleaned = _validated(intervals)
    cleaned.sort(key=lambda interval: interval[0])

    merged = []
    for start, end in cleaned:
        if merged and start <= merged[-1][1]:
            if end > merged[-1][1]:
                merged[-1][1] = end
        else:
            merged.append([start, end])

    return merged


def contains(intervals, point):
    """Return whether point lies in any half-open interval."""
    _check_int(point, "point")
    normalized = normalize(intervals)
    return any(start <= point < end for start, end in normalized)


def gaps(intervals, start, end):
    """Return uncovered portions of the half-open window [start, end)."""
    _check_int(start, "window start")
    _check_int(end, "window end")

    if end < start:
        raise ValueError("window end must be greater than or equal to start")

    normalized = normalize(intervals)

    if start == end:
        return []

    covered = []
    for interval_start, interval_end in normalized:
        clipped_start = max(interval_start, start)
        clipped_end = min(interval_end, end)
        if clipped_start < clipped_end:
            covered.append((clipped_start, clipped_end))

    result = []
    cursor = start

    for covered_start, covered_end in covered:
        if covered_start > cursor:
            result.append([cursor, covered_start])
        if covered_end > cursor:
            cursor = covered_end

    if cursor < end:
        result.append([cursor, end])

    return result
