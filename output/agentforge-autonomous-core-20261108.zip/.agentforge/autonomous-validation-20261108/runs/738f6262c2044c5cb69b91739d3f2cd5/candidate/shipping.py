"""Shipping quote.

Provenance: the supplied baseline deliberately used floor division for
additional kilograms, so non-multiple additional kilograms were undercharged.
This repair uses ceiling division so every started additional 1000g is charged
200 cents.
"""


def shipping_cost(weights, subtotal_cents, express=False):
    if not isinstance(weights, list) or any(type(w) is not int or w <= 0 for w in weights):
        raise ValueError("weights must be positive integer grams")
    if type(subtotal_cents) is not int or subtotal_cents < 0:
        raise ValueError("subtotal must be non-negative integer cents")
    if type(express) is not bool:
        raise ValueError("express must be bool")
    if not weights:
        return 0
    if subtotal_cents >= 5000:
        base = 0
    else:
        additional = max(0, sum(weights) - 1000)
        # Every started additional 1000g is chargeable; use ceiling division.
        base = 500 + ((additional + 999) // 1000) * 200
    return base + (400 if express else 0)
