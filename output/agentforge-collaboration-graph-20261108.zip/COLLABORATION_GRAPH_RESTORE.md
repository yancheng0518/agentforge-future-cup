# 协作图复现包：只在全新目录恢复

本包包含当前源码、17 项旧工作台历史、6 项动态运行（含所有失败与否定结论）、
本轮真实执行及预声明独立 Docker 验收证据。不得将本包直接解压覆盖 D:\未来杯，
也不要把包内数据库复制回正在使用的项目目录。

1. 创建一个从未用于 AgentForge 的全新空目录，将整个 ZIP 解压到该目录。
2. 包内 .agentforge/agentforge.sqlite3 和 .agentforge/autonomous/agentforge.sqlite3
   已是打包时通过 SQLite backup API 获得的一致性快照，分别包含 17 和 6 项历史；
   无需执行复制、覆盖、数据库清空或恢复脚本。原始备份另存于
   output/collaboration-graph-20261108/legacy-final.sqlite3 和 autonomous-api-final.sqlite3。
3. 在新目录按 README.md 使用锁定依赖重建虚拟环境和前端依赖，再从新目录启动服务。
   新目录内不含 .env、凭据、依赖缓存或 WSL 镜像。仅浏览历史不会发送新模型请求；
   如需重新运行，另按 .env.example 在新目录配置自己的凭据与 Docker。
4. 旧项目服务占用端口时，不要同时启动新目录服务到同一端口。阅读和核对 JSON/ZIP
   证据无需启动任何服务。不得在宿主机直接运行候选代码，执行验证只使用 Docker。

包内 REPRODUCTION_MANIFEST.json 记录每个成员的 SHA-256 和大小，以及两个数据库
快照的逐表/逐行摘要。可在不解压、不执行候选的情况下核验：

    python scripts/export_reproduction.py --verify <本ZIP的路径>

归档工具不发模型请求、不启动 Docker，不改当前数据库或历史文件。
历史“运行成功”并不自动代表业务正确，请同时查看 quality_review/posthoc_review：
原测试通过后被后验检查否定的记录仍完整保留。换机从零启动尚未在本轮实测。
